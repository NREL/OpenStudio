  iconv 1.8
  ---------

  This is the iconv, version 1.8, binary package for native Win32/IA32 
platform.

  The directory named 'include' contains the header files. Place its 
contents somewhere where it can be found by the compiler.
  The directory which answers to the name 'lib' contains the static and 
dynamic libraries. Place them somewhere where they can be found by the 
linker. The files whose names end with '_a.lib' are aimed for static 
linking, the other files are lib/dll pairs.
  The directory called 'util' contains various programs which count as a part
of iconv.

  If there is something you cannot keep for yourself, such as a problem, a
cheer of joy, a comment or a suggestion, feel free to contact me using the
address below.


                                   Igor Zlatkovic (igor@stud.fh-frankfurt.de)
