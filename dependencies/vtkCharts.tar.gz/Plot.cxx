/*=========================================================================

  Program:   vtkCharts
  Module:    Plot.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "Plot.h"

#include "Color.h"

#include "vtkPlotLine.h"
#include "vtkTable.h"
#include "vtkFloatArray.h"
#include "vtkPen.h"
#include "vtkBrush.h"
#include "vtkNew.h"

namespace vtkCharts {

namespace {

inline void VectorToArray(const std::vector<float>& vec,
                          vtkFloatArray *array)
{
  array->SetNumberOfTuples(vec.size());
  for (vtkIdType i = 0; i < vec.size(); ++i)
    {
    array->SetValue(i, vec[i]);
    }
}

}

class PlotPimpl
{
public:
  PlotPimpl(vtkPlotLine *plot = 0, vtkTable *table = 0) :
    Plot(plot), Table(table)
  {
  }

  ~PlotPimpl()
  {
  }

  void SetData(const std::vector<float>& x, const std::vector<float>& y,
               const std::string& seriesName, vtkPlotLine *plot = 0)
  {
    if (!plot && !this->Plot)
      {
      return;
      }
    else if (plot)
      {
      this->Plot = plot;
      }
    if (!this->Table)
      {
      this->Table = vtkSmartPointer<vtkTable>::New();
      }

    vtkNew<vtkFloatArray> xArray;
    VectorToArray(x, xArray.GetPointer());
    vtkNew<vtkFloatArray> yArray;
    VectorToArray(y, yArray.GetPointer());

    xArray->SetName("X");
    yArray->SetName(seriesName.c_str());

    this->Table->AddColumn(xArray.GetPointer());
    this->Table->AddColumn(yArray.GetPointer());
    this->Plot->SetInput(this->Table.GetPointer(), 0, 1);
  }

  void SetLineStyle(Plot::LineStyle style)
  {
    if (this->Plot)
      {
      switch (style)
        {
        case Plot::DOTTED:
          this->Plot->GetPen()->SetLineType(vtkPen::DOT_LINE);
          break;
        case Plot::PATTERN_1:
          this->Plot->GetPen()->SetLineType(vtkPen::DASH_LINE);
          break;
        case Plot::PATTERN_2:
          this->Plot->GetPen()->SetLineType(vtkPen::DASH_DOT_LINE);
          break;
        case Plot::PATTERN_3:
          this->Plot->GetPen()->SetLineType(vtkPen::DASH_DOT_DOT_LINE);
          break;
        case Plot::NONE:
          this->Plot->GetPen()->SetLineType(vtkPen::NO_PEN);
          break;
        case Plot::SOLID:
        default:
          this->Plot->GetPen()->SetLineType(vtkPen::SOLID_LINE);
        }
      }
  }

  void SetMarkerStyle(Plot::MarkerStyle style)
  {
    this->Plot->SetMarkerStyle(style);
  }

  vtkSmartPointer<vtkPlotLine> Plot;
  vtkSmartPointer<vtkTable> Table;
};

Plot::Plot(vtkPlotLine *plot)
{
  this->Private = new PlotPimpl();
  this->Private->Plot = plot;
}

Plot::~Plot()
{
  if (this->Private)
    delete this->Private;
  this->Private = 0;
}

void Plot::setData(const std::vector<float>& x,
                   const std::vector<float>& y,
                   const std::string& seriesName)
{
  static_cast<PlotPimpl *>(this->Private)->SetData(x, y, seriesName);
}

void Plot::setLineStyle(Plot::LineStyle style)
{
  static_cast<PlotPimpl *>(this->Private)->SetLineStyle(style);
}

Plot::LineStyle Plot::lineStyle() const
{
  switch(static_cast<PlotPimpl *>(this->Private)->Plot->GetPen()->GetLineType())
    {
    case vtkPen::DOT_LINE:
      return DOTTED;
    case vtkPen::DASH_LINE:
      return Plot::PATTERN_1;
    case vtkPen::DASH_DOT_LINE:
      return Plot::PATTERN_2;
    case vtkPen::DASH_DOT_DOT_LINE:
      return Plot::PATTERN_3;
    case vtkPen::NO_PEN:
      return Plot::NONE;
    case vtkPen::SOLID_LINE:
    default:
      return Plot::SOLID;
    }
}

void Plot::setMarkerStyle(Plot::MarkerStyle style)
{
  this->Private->SetMarkerStyle(style);
}

Plot::MarkerStyle Plot::markerStyle() const
{
  switch(this->Private->Plot->GetMarkerStyle())
    {
    case vtkPlotPoints::NONE:
      return EMPTY;
    case vtkPlotPoints::CROSS:
      return CROSS;
    case vtkPlotPoints::PLUS:
      return PLUS;
    case vtkPlotPoints::SQUARE:
      return SQUARE;
    case vtkPlotPoints::CIRCLE:
      return CIRCLE;
    case vtkPlotPoints::DIAMOND:
    default:
      return DIAMOND;
    }
}

void Plot::setMarkerSize(float size)
{
  this->Private->Plot->SetMarkerSize(size);
}

float Plot::markerSize() const
{
  return this->Private->Plot->GetMarkerSize();
}

void Plot::setColor(const Color3ub &color)
{
  vtkColor4ub vtkColor(color.Red(), color.Green(), color.Blue());
  this->Private->Plot->GetPen()->SetColor(vtkColor);
  this->Private->Plot->GetBrush()->SetColor(vtkColor);
}

void Plot::setColor(const Color4ub &color)
{
  vtkColor4ub vtkColor(color.Red(), color.Green(), color.Blue(), color.Alpha());
  this->Private->Plot->GetPen()->SetColor(vtkColor);
  this->Private->Plot->GetBrush()->SetColor(vtkColor);
}

Color4ub Plot::color() const
{
  vtkColor4ub vtkColor = this->Private->Plot->GetPen()->GetColorObject();
  return Color4ub(vtkColor.Red(), vtkColor.Green(), vtkColor.Blue(),
                  vtkColor.Alpha());
}

vtkPlotLine * Plot::plotObject()
{
  return this->Private->Plot.GetPointer();
}

// It is all about keeping a copy of the Axis pointer.
Plot::Plot(const Plot &other) :
  Private(new PlotPimpl(other.Private->Plot, other.Private->Table))
{
}

bool Plot::isValid() const
{
  return this->Private->Plot == 0 ? false : true;
}

void Plot::setPlotObject(vtkPlotLine *plot)
{
  this->Private->Plot = plot;
}

} // End of vtkCharts namespace
