/*=========================================================================

  Program:   vtkCharts
  Module:    Legend.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "Legend.h"

#include "vtkChartLegend.h"
#include "vtkWeakPointer.h"

namespace vtkCharts {

class LegendPimpl
{
public:
  LegendPimpl(vtkChartLegend *legend) : Legend(legend) {}
  vtkWeakPointer<vtkChartLegend> Legend;
};

void Legend::setVerticalAlignment(Alignment align)
{
  if (this->Private->Legend)
    {
    this->Private->Legend->SetVerticalAlignment(align);
    }
}

Legend::Alignment Legend::verticalAlignment() const
{
  if (!this->Private->Legend)
    {
    return CUSTOM;
    }
  switch(this->Private->Legend->GetVerticalAlignment())
    {
    case vtkChartLegend::TOP:
      return TOP;
    case vtkChartLegend::CENTER:
      return CENTER;
    case vtkChartLegend::BOTTOM:
      return BOTTOM;
    default:
      return CUSTOM;
    }
}

void Legend::setHorizontalAlignment(Alignment align)
{
  if (this->Private->Legend)
    {
    this->Private->Legend->SetHorizontalAlignment(align);
    }
}

Legend::Alignment Legend::horizontalAlignment() const
{
  if (!this->Private->Legend)
    {
    return CUSTOM;
    }
  switch(this->Private->Legend->GetHorizontalAlignment())
    {
    case vtkChartLegend::LEFT:
      return LEFT;
    case vtkChartLegend::CENTER:
      return CENTER;
    case vtkChartLegend::RIGHT:
      return RIGHT;
    default:
      return CUSTOM;
    }
}

void Legend::setInline(bool isInline)
{
  if (this->Private->Legend)
    {
    this->Private->Legend->SetInline(isInline);
    }
}

bool Legend::isInline() const
{
  return this->Private->Legend ?
        this->Private->Legend->GetInline() : true;
}

Legend::Legend(vtkChartLegend *legend) : Private(new LegendPimpl(legend))
{
}

Legend::~Legend()
{
  delete this->Private;
  this->Private = 0;
}

// It is all about keeping a copy of the Legend pointer.
Legend::Legend(const Legend &other) :
  Private(new LegendPimpl(other.Private->Legend))
{
}

} // End namespace
