/*=========================================================================

  Program:   vtkCharts
  Module:    BaseChart.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "BaseChartPimpl.h"
#include "Color.h"

#include "vtkChartXY.h"
#include "vtkAxis.h"

#ifdef vtkCharts_USE_QT
# include "QVTKWidget.h"
#else
# include "vtkContextView.h"
# include "vtkRenderWindow.h"
#endif

namespace vtkCharts
{

void BaseChart::setColors(const std::vector<Color3ub>& colors)
{
  this->Private->setColors(colors);
}

void BaseChart::setTitle(const std::string &title)
{
  this->Private->Chart->SetTitle(title.c_str());
}

std::string BaseChart::title() const
{
  return this->Private->Chart->GetTitle();
}

void BaseChart::rescale()
{
  this->Private->Chart->RecalculateBounds();
}

Axis BaseChart::axis(Axis::Position axisPosition)
{
  return Axis(this->Private->Chart->GetAxis(axisPosition));
}

const Axis BaseChart::axis(Axis::Position axisPosition) const
{
  return Axis(this->Private->Chart->GetAxis(axisPosition));
}

Legend BaseChart::legend()
{
  return Legend(this->Private->Chart->GetLegend());
}

const Legend BaseChart::legend() const
{
  return Legend(this->Private->Chart->GetLegend());
}

void BaseChart::setShowLegend(bool show)
{
  this->Private->Chart->SetShowLegend(show);
}

void BaseChart::setSize(int width, int height)
{
#ifdef vtkCharts_USE_QT
  this->Private->VTKWidget->setGeometry(0, 0, width, height);
#else
  this->Private->Context->GetRenderWindow()->SetSize(width, height);
#endif
}

void BaseChart::setDrawEmpty(bool draw)
{
  this->Private->Chart->SetRenderEmpty(draw);
}

bool BaseChart::drawEmpty() const
{
  return this->Private->Chart->GetRenderEmpty();
}

#ifdef vtkCharts_USE_QT
QWidget *BaseChart::widget(QWidget *parent)
{
  if (parent)
    this->Private->VTKWidget->setParent(parent);

  return this->Private->VTKWidget;
}
#endif

void BaseChart::setFileType(BaseChart::FileType type)
{
  this->Private->FileType = type;
}

void BaseChart::save(const std::string &fileName)
{
  this->Private->save(fileName);
}

BaseChart::TestReturn BaseChart::test(int argc, char *argv[], double threshold)
{
  return this->Private->test(argc, argv, threshold);
}

} // End of vtkCharts namespace
