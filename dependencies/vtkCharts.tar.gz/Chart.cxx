/*=========================================================================

  Program:   vtkCharts
  Module:    Chart.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "Chart.h"

#include "Plot.h"
#include "BaseChartPimpl.h"
#include "Color.h"

#ifdef vtkCharts_USE_QT
# include "QChartProxy.h"
#endif

#include "vtkPlotLine.h"
#include "vtkChartXY.h"
#include "vtkTable.h"
#include "vtkFloatArray.h"
#include "vtkPen.h"
#include "vtkBrush.h"
#include "vtkColorSeries.h"

namespace vtkCharts {

class ChartPimpl : public BaseChartPimpl
{
public:
  ChartPimpl() : BaseChartPimpl(vtkChartXY::New())
  {
#ifdef vtkCharts_USE_QT
    this->ChartProxy = 0;
#endif
  }

  ~ChartPimpl()
  {
  }

  void setColors(const std::vector<Color3ub>& colors)
  {
    BaseChartPimpl::setColors(colors);

    std::map<std::string, vtkSmartPointer<vtkPlotLine> >::const_iterator iter;
    int i = 0;
    for (iter = this->Plots.begin(); iter != this->Plots.end(); iter++,i++)
      {
      iter->second->GetPen()->SetColor(
            this->ColorSeries->GetColorRepeating(i).GetData());
      }
  }

  vtkPlotLine * AddPlot(const std::string& seriesName)
  {
    this->Plots[seriesName] =
        vtkPlotLine::SafeDownCast(this->Chart->AddPlot(vtkChartXY::LINE));
    this->Plots[seriesName]->GetPen()->SetColor(
          this->ColorSeries->GetColorRepeating(this->Plots.size() - 1).GetData());
    this->Plots[seriesName]->GetBrush()->SetColor(
          this->ColorSeries->GetColorRepeating(this->Plots.size() - 1).GetData());

    return this->Plots[seriesName];
  }

  vtkPlotLine * GetPlot(const std::string& seriesName)
  {
    if (this->Plots.find(seriesName) != this->Plots.end())
      {
      return this->Plots[seriesName];
      }
    else
      {
      return 0;
      }
  }

  QChartProxy * chartProxy() const
  {
#ifdef vtkCharts_USE_QT
    return this->ChartProxy;
#else
    return NULL;
#endif
  }

  std::map<std::string, vtkSmartPointer<vtkPlotLine> > Plots;
#ifdef vtkCharts_USE_QT
  QChartProxy *ChartProxy;
#endif

};

Chart::Chart()
{
  this->Private = new ChartPimpl();
}

Chart::Chart(const std::vector<float>& x, const std::vector<float>& y,
             const std::string& seriesName)
{
  this->Private = new ChartPimpl();
  this->addPlot(x, y, seriesName);
}

Chart::~Chart()
{
  if (this->Private)
    delete this->Private;
  this->Private = 0;
}

void Chart::setColors(const std::vector<Color3ub> &colors)
{
  static_cast<ChartPimpl *>(this->Private)->setColors(colors);
}

Plot Chart::addPlot(const std::vector<float>& x,
                    const std::vector<float>& y,
                    const std::string& seriesName)
{
  vtkPlotLine *line = static_cast<ChartPimpl *>(this->Private)->AddPlot(seriesName);
  Plot plot(line);
  plot.setData(x, y, seriesName);
  return plot;
}

Plot Chart::plot(const std::string &seriesName)
{
  return Plot(static_cast<ChartPimpl *>(this->Private)->GetPlot(seriesName));
}

vtkCharts::QChartProxy * Chart::chartProxy()
{
#ifdef vtkCharts_USE_QT
  ChartPimpl *chartPimpl = static_cast<ChartPimpl *>(this->Private);
  if (!chartPimpl->ChartProxy)
    {
    chartPimpl->ChartProxy = new QChartProxy(this);
    }
  return chartPimpl->chartProxy();
#else
  return 0;
#endif
}

void Chart::setAutoAxes(bool val)
{
  static_cast<vtkChartXY *>(this->Private->Chart.GetPointer())->SetAutoAxes(val);
}

bool Chart::autoAxes() const
{
  return static_cast<vtkChartXY *>(this->Private->Chart.GetPointer())->GetAutoAxes();
}

vtkChartXY * Chart::chartObject() const
{
  return vtkChartXY::SafeDownCast(this->Private->Chart.GetPointer());
}

} // End of vtkCharts namespace
