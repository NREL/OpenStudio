/*=========================================================================

  Program:   vtkCharts
  Module:    BaseChart.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsBaseChart_h
#define __vtkChartsBaseChart_h

#include "Axis.h"
#include "Legend.h"

#include <vector>
#include <string>

class QWidget;

namespace vtkCharts {
class Color3ub;
class BaseChartPimpl;

/*! @brief Base class for building vtkCharts Charts
 */
class BaseChart
{
public:

  /*!
   * @brief Used to specify the file type written by vtkCharts::BaseChart::save.
   */
  enum FileType {
    JPEG,
    PNG
    };

  /*!
   * @brief Used to specify the the result of vtkCharts::BaseChart::test
   */
  enum TestReturn {
    FAILED = 0,              //! The Test failed.
    PASSED = 1,              //! The Test passed.
    NOT_RUN = 2,             //! The Test could not be run.
    INTERACT = 3             //! The Test arguments requested interactive mode.
    };

  /*! @brief Set the title of the chart.
   * @param title The string to use as the title of the chart.
   */
  void setTitle(const std::string &title);

  /*! Get the title of the chart.
   * @return The title of the chart.
   */
  std::string title() const;

  /*! Rescale the chart bounds to fit the data. This will cause the active
   * axes to find an optimal range for visible data in the chart. */
  void rescale();

  /*! @brief Get the specified axis.
   * @param axisPosition The AxisPosition enum (LEFT, BOTTOM, RIGHT or TOP) to
   * get.
   */
  Axis axis(Axis::Position axisPosition);
  const Axis axis(Axis::Position axisPosition) const;

  /*! @brief Get the legend for this chart. */
  Legend legend();
  const Legend legend() const;

  /*! @brief Control the display of the Chart legend.
   *
   * @param show Show the Chart legend if true.
   */
  void setShowLegend(bool show);

  /*! @brief Set the series of colors use by this chart.
   *
   * @param colors Vector of colors used in sequence as the Chart is built up.
   */
  void setColors(const std::vector<vtkCharts::Color3ub>& colors);

  /*! @brief Set the overall size of the Chart.
   *
   * @param width Width of the Chart in pixels.
   * @param height Height of the Chart in pixels.
   */
  void setSize(int width, int height);

  /*! @brief Should the chart draw an empty plot (axes, decorations).
   * Default is false (draw nothing) if no plots are visiable.
   *
   * @note For Chart objects, you must also set autoAxes to false if you
   * wish to see the x and y axes displayed.
   */
  void setDrawEmpty(bool draw);

  /*! @brief True if an empty chart will be drawn, false if not (default). */
  bool drawEmpty() const;

#ifdef vtkCharts_USE_QT
  /*! @brief Returns a QWidget containing the Chart.
   *
   * @param parent Optional parent to the returned Widget.
   */
  QWidget * widget(QWidget *parent=0);
#endif

  /*! @brief Set the file format to use when calling vtkCharts::BaseChart::Save
   * is called.
   *
   * @param type Choose the vtkCharts::BaseChart::FileType to when
   * vtkCharts::BaseChart::Save is called.
   */
  void setFileType(FileType type);

  /*! @brief Save a graphical representation of the Chart.
   *
   * @param type Choose the vtkCharts::BaseChart::FileType to when
   * vtkCharts::BaseChart::Save is called.
   */
  void save(const std::string& filename);

  /*! @brief Run an image based regression test, with the supplied threshold.
   *
   * @param threshold The image difference threshold.
   */
  TestReturn test(int argc, char *argv[], double threshold = 10.0);

protected:
  BaseChartPimpl *Private;
};

}

#endif
