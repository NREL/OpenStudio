/*=========================================================================

  Program:   vtkCharts
  Module:    FloodPlot.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsFloodPlot_h
#define __vtkChartsFloodPlot_h

#include "BaseChart.h"

#include <string>

namespace vtkCharts {

class Color3ub;
class Matrixf;

/*! @brief Implements a basic flood plot.
 */
class FloodPlot : public BaseChart
{
public:
  /*! @brief Construct a flood plot.
   *
   * @param m The matrix of scalar values that should make up the 2D histogram.
   * @param xMin The minimum value in x.
   * @param xMax The maximum value in x.
   * @param yMin The minimum value in y.
   * @param yMax The maximum value in y.
   * @param name The name of this dataset.
   */
  FloodPlot(const Matrixf& m, float xMin, float xMax,
            float yMin, float yMax,
            const std::string& name);

  ~FloodPlot();

  /*! @brief Set the input data for the flood plot.
   *
   * @param m The matrix of scalar values that should make up the flood plot.
   * @param xMin The minimum value in x.
   * @param xMax The maximum value in x.
   * @param yMin The minimum value in y.
   * @param yMax The maximum value in y.
   * @param name The name of this dataset.
   */
  void setInput(const Matrixf& m, float xMin, float xMax,
                float yMin, float yMax,
                const std::string& name);
};

}

#endif
