require 'vtkCharts'

red = VtkCharts::Color3ub.new(255, 0, 0)
blue = VtkCharts::Color3ub.new(0, 255, 0)
green = VtkCharts::Color3ub.new(0, 0, 255)

colors = VtkCharts::Color3ubVector.new
colors << red

pie = VtkCharts::PieChart.new([1,2,3,4,5,6])
pie.setFileType(VtkCharts::BaseChart::PNG)
pie.save('./pie.png')

bar = VtkCharts::BarChart.new([1,2,3,4,5,6], "Series")
bar.setFileType(VtkCharts::BaseChart::PNG)
bar.save('./bar.png')

line = VtkCharts::Chart.new([1,2,3,4,5,6], [1,2,3,4,5,6], "Series")
line.setColors(colors)
line.setFileType(VtkCharts::BaseChart::PNG)
line.save('./line.png')

matrix = VtkCharts::Matrixf.new(400, 200)
(0...400).each do |i|
  (0...200).each do |j|
    matrix[i,j] = i + j
  end
end
hist = VtkCharts::FloodPlot.new(matrix, 0.0, 400.0, 0.0, 200.0, "Data")
hist.setFileType(VtkCharts::BaseChart::PNG)
hist.setTitle("Test Chart")
hist.setXLabel("X")
hist.setYLabel("Y")
hist.save('./hist.png')
