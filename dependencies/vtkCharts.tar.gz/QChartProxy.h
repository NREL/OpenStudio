/*=========================================================================

  Program:   vtkCharts
  Module:    QChartProxy.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsQChartProxy_h
#define __vtkChartsQChartProxy_h

#include <QtCore/QObject>

#include "Vector.h"

#include "vtkNew.h"

class vtkObject;
class vtkCommand;
class vtkEventQtSlotConnect;

namespace vtkCharts {

class Chart;

class QChartProxy : public QObject
{
  Q_OBJECT
public:
  explicit QChartProxy(Chart *chart = 0, QObject *parent = 0);
  ~QChartProxy();

signals:
  /*!
   * Emitted when a point is clicked on.
   *
   * @param seriesName The name of the series that contains the point clicked on.
   * @param position The x, y position of the point that was clicked on in chart
   * coordinates.
   * @param screenPosition The x, y position of the point that was clicked in
   * screen coordinates (note the origin is bottom-left).
   */
  void pointClicked(QString seriesName, Vector2f position,
                    Vector2i screenPosition);

public slots:
  void chartPointClicked(vtkObject *caller, unsigned long vtk_event,
                         void* client_data, void *client_data2, vtkCommand*);

protected:
  Chart *ChartObject;
  vtkNew<vtkEventQtSlotConnect> Connector;
};

} // End of namespace

#endif
