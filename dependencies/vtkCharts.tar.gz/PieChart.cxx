/*=========================================================================

  Program:   vtkCharts
  Module:    PieChart.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "PieChart.h"
#include "Color.h"
#include "BaseChartPimpl.h"

#include <map>

#include "vtkTable.h"
#include "vtkFloatArray.h"
#include "vtkDoubleArray.h"
#include "vtkStringArray.h"

#include "vtkColorSeries.h"
#include "vtkPen.h"
#include "vtkBrush.h"

#include "vtkChartPie.h"
#include "vtkPlotPie.h"
#include "vtkAxis.h"
#include "vtkSmartPointer.h"

namespace vtkCharts {

class PieChartPimpl : public BaseChartPimpl
{
public:
  PieChartPimpl(void) : BaseChartPimpl(vtkChartPie::New())
    {
    }

  ~PieChartPimpl()
    {
    }

  void SetDataSeries(const std::vector<float>& series)
    {
    this->Plot = vtkPlotPie::SafeDownCast(this->Chart->AddPlot(0));
    this->Plot->SetColorSeries(this->ColorSeries);
    this->Table = vtkSmartPointer<vtkTable>::New();

    vtkSmartPointer<vtkFloatArray> floatArray =
        vtkSmartPointer<vtkFloatArray>::New();
    VectorToArray(series, floatArray);
    floatArray->SetName("DATA");
    this->Table->AddColumn(floatArray);
    this->Plot->SetInput(this->Table);
    this->Plot->SetInputArray(0, "DATA");
    }

  void SetWedgeLabels(const std::vector<std::string>& labels)
    {
    vtkSmartPointer<vtkStringArray> labelArray =
        vtkSmartPointer<vtkStringArray>::New();
    std::vector<std::string>::const_iterator label;
    for (label = labels.begin(); label != labels.end(); ++label)
      {
      labelArray->InsertNextValue(*label);
      }
    this->Plot->SetLabels(labelArray);
    }

  vtkSmartPointer<vtkPlotPie> Plot;
  vtkSmartPointer<vtkTable> Table;

};

PieChart::PieChart(const std::vector<float>& data)
{
  this->Private = new PieChartPimpl();
  static_cast<PieChartPimpl *>(this->Private)->SetDataSeries(data);
}

PieChart::~PieChart()
{
  if (this->Private)
    delete this->Private;
  this->Private = 0;
}

void PieChart::setSeries(const std::vector<float>& series)
{
  static_cast<PieChartPimpl *>(this->Private)->SetDataSeries(series);
}

void PieChart::setWedgeLabels(const std::vector<std::string>& labels)
{
  static_cast<PieChartPimpl *>(this->Private)->SetWedgeLabels(labels);
}

} // End of vtkCharts namespace
