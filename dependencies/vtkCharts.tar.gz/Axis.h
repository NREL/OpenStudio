/*=========================================================================

  Program:   vtkCharts
  Module:    Axis.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsAxis_h
#define __vtkChartsAxis_h

#include <string>
#include <vector>

// Declare the VTK classes, opaque until the headers are included
class vtkAxis;

namespace vtkCharts {

class AxisPimpl;
class BaseChart;

class Axis
{
public:
  /*! Axis position enum. */
  enum Position {
    LEFT,
    BOTTOM,
    RIGHT,
    TOP
  };

  /*! Tick notation styles. */
  enum Notation {
    STANDARD = 0,
    SCIENTIFIC,
    MIXED
  };

  ~Axis();

  /*! Set the title of the axis (the label that will be displayed on the axis.
   * @param title The title to be set.
   */
  void setTitle(const std::string &title);

  /*! Get the title of the axis.
   * @return The current title of the axis.
   */
  std::string title() const;

  /*! Set the minimum value of the axis. */
  void setMinimum(double value);

  /*! Get the minimum value of the axis. */
  double minimum() const;

  /*! Set the maximum value of the axis. */
  void setMaximum(double value);

  /*! Get the maximum value of the axis. */
  double maximum() const;

  /*! Set the range of the axis. */
  void setRange(double minimum, double maximum);

  /*! Set the number of ticks for the axis. */
  void setNumberOfTicks(int ticks);

  /*! Get the number of ticks for the axis. */
  int numberOfTicks() const;

  /*! Set the tick notation, using the LabelStyle enum. */
  void setNotation(Notation style);

  /*! Get the tick notation, using the LabelStyle enum. */
  Notation notation() const;

  /*! Set the precision of the tick labels. */
  void setPrecision(int precision);

  /*! Get the precision of the tick labels. */
  int precision() const;

  /*! Set custom tick labels on the axis. */
  void setTickLabels(const std::vector<std::string> &labels);

  /*! Get the vtkAxis that this class is acting upon.
   * @note Generally should not be called by users of the charts, can be useful
   * for manipulating the underlying vtkAxis object.
   */
  vtkAxis * axisObject();

  /*! Copy constructor. */
  Axis(const Axis &other);

protected:
  friend class BaseChart;

  Axis(vtkAxis *axis = 0);

  /*! Set the vtkAxis that this class is acting upon.
   * @param axis The vtkAxis object.
   * @note Generally should not be called by users of the charts.
   */
  void setAxisObject(vtkAxis *axis);

private:
  AxisPimpl *Private;
};

} // End of namespace

#endif
