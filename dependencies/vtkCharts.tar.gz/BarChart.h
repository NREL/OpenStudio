/*=========================================================================

  Program:   vtkCharts
  Module:    BarChart.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsBarChart_h
#define __vtkChartsBarChart_h

#include <vector>
#include <string>

#include "BaseChart.h"

namespace vtkCharts {
class Color3ub;
class BarChartPimpl;

/*!
 * @brief vtkCharts class for generating bar and stacked bar charts.
 *
 * A simple bar chart can be created with code like the following:
 *
 * @code
 *
 * std::vector<float> series(3);
 * series[0] = 3.0;
 * series[1] = 5.0;
 * series[2] = 7.0;
 * vtkCharts::BarChart chart(series, "Test");
 *
 * @endcode
 *
 * A stacked bar chart would be created like this:
 *
 * @code
 *
 * std::vector<float> series1(3);
 * series1[0] = 3.0;
 * series1[1] = 5.0;
 * series1[2] = 7.0;
 *
 * std::vector<float> series2(3);
 * series2[0] = 0.9;
 * series2[1] = 1.1;
 * series2[3] = 1.5;
 *
 * vtkCharts::BarChart chart("Base");
 * chart.stackSeries(series1, "Base", "First");
 * chart.stackSeries(series2, "Base", "Second");
 *
 * @endcode
 *
 */

class BarChart : public BaseChart
{
public:
  /*!
   * @brief Create a BarChart with one data series.
   *
   * @param series A single data series with which to construct the bar chart.
   * @param seriesName The name of the data series. Used when stacking data
   * series.
   */
  BarChart(const std::vector<float>& series, const std::string& seriesName);

  /*!
   * @brief Create BarChart with no initial series.
   *
   * @param seriesName Used to later stack data.
   */
  BarChart(const std::string& seriesName);

  ~BarChart();

  /*!
   * @brief Add a data series to the BarChart.
   *
   * The data series is automatically added as a grouped bar if other series are
   * present. If a previous series with the same name exists, it is replaced
   * with this series.
   *
   * @param series The data series to add.
   * @param seriesName The name of this data series.
   */
  void addSeries(const std::vector<float>& series,
                 const std::string& seriesName);

  /*!
   * @brief Remove the named data series.
   *
   * @param seriesName The name of the series to remove.
   * @return True on success, false on failure.
   */
  bool removeSeries(const std::string& seriesName);

  /*!
   * @brief Stack a data series on top of a previously established series.
   *
   * This is the routine used to create a stacked  BarChart.
   *
   * @param series The data series to stack.  Must have the same number of
   * elements as its "base".
   * @param seriesName The name of the series to use as the base for this one.
   * @param stackName  The name of this data series.
   */
  void stackSeries(const std::vector<float>& series,
                   const std::string& seriesName,
                   const std::string& stackName);

  /*!
   * @brief Set the label for each bar, bar group or bar stack.
   *
   * @param labels The names of the tick labels.  Length must correspond to
   * the length of the data series in this BarChart.
   *
   * @note This provides some bar chart aware spacing on the x axis.
   */
  void setXTickLabels(const std::vector<std::string>& labels);
};

}

#endif
