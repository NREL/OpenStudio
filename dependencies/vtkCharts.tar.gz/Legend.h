/*=========================================================================

  Program:   vtkCharts
  Module:    Legend.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsLegend_h
#define __vtkChartsLegend_h

// Declare the VTK classes, opaque until the headers are included
class vtkChartLegend;

namespace vtkCharts {

class LegendPimpl;
class BaseChart;

class Legend
{
public:
  /*! Legend alignment enum. */
  enum Alignment {
    LEFT = 0,
    CENTER,
    RIGHT,
    TOP,
    BOTTOM,
    CUSTOM
    };

  ~Legend();

  /*! Set the legend's vertical alignment, using the Alignment enum.
   * Valid values are TOP, CENTER, BOTTOM or CUSTOM.
   */
  void setVerticalAlignment(Alignment align);

  /*! Get the legend's vertical alignment, using the Alignment enum.
   * Possible values are TOP, CENTER, BOTTOM or CUSTOM.
   */
  Alignment verticalAlignment() const;

  /*! Set the legend's horizontal alignment, using the Alignment enum.
   * Valid values are LEFT, CENTER, RIGHT or CUSTOM.
   */
  void setHorizontalAlignment(Alignment align);

  /*! Get the legend's vertical alignment, using the Alignment enum.
   * Possible values are LEFT, CENTER, RIGHT or CUSTOM.
   */
  Alignment horizontalAlignment() const;

  /*! Set whether the legend should be displayed inline in theh chart.
   * Default value is true.
   */
  void setInline(bool isInline);

  /*! Get whether the legend should be displayed inline in theh chart.
   * Default value is true.
   */
  bool isInline() const;

  /*! Copy constructor. */
  Legend(const Legend &other);

protected:
  friend class BaseChart;
  Legend(vtkChartLegend *legend = 0);

private:
  LegendPimpl *Private;
};

} // End namespace

#endif
