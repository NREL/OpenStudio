#include <iostream>
#include <vector>
#include <string>

#include "BarChart.h"

#include "vtkDataArray.h"

#ifdef vtkCharts_USE_QT
#include <QApplication>
#include <QWidget>
#endif

int TestBarChart(int argc, char *argv [])
{
#ifdef vtkCharts_USE_QT
  QApplication application(argc,argv);
#endif

  std::vector<float> series1_floats(3);
  series1_floats[0] = 3.0;
  series1_floats[1] = 5.0;
  series1_floats[2] = 7.0;

  std::vector<float> series2_floats(3);
  series2_floats[0] = 7.0;
  series2_floats[1] = 3.0;
  series2_floats[2] = 5.0;

  std::vector<float> series3_floats(3);
  series3_floats[0] = 5.0;
  series3_floats[1] = 7.0;
  series3_floats[2] = 3.0;

  std::vector<std::string> labels(3);
  labels[0] = std::string("First");
  labels[1] = std::string("Second");
  labels[2] = std::string("Third");

  vtkCharts::BarChart chart(series1_floats, "One");
  chart.addSeries(series2_floats, "Two");
  chart.addSeries(series3_floats, "Three");

  chart.setTitle("Test Chart");
  chart.axis(vtkCharts::Axis::LEFT).setTitle("Numbers");
  chart.setXTickLabels(labels);

  vtkCharts::BarChart::TestReturn retVal = chart.test(argc,argv,25.0);
#ifdef vtkCharts_USE_QT
  if (retVal == vtkCharts::BaseChart::INTERACT)
    application.exec();
#endif

  return !retVal;
}
