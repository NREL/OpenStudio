#include <iostream>
#include <vector>
#include <string>

#include "PieChart.h"

#include "vtkDataArray.h"

#ifdef vtkCharts_USE_QT
# include <QApplication>
# include <QWidget>
#endif

int TestPieChart(int argc, char *argv [])
{
#ifdef vtkCharts_USE_QT
  QApplication application(argc, argv);
#endif

  std::vector<float> wedges(3);
  wedges[0] = 16.0;
  wedges[1] = 60.0;
  wedges[2] = 24.0;

  std::vector<std::string> labels(3);
  labels[0] = "Lights On";
  labels[1] = "Unoccupied";
  labels[2] = "Occupied and Daylit";

  vtkCharts::PieChart chart(wedges);
  chart.setWedgeLabels(labels);
  chart.setShowLegend(true);

  chart.setTitle("General Building Lights");

  vtkCharts::BaseChart::TestReturn retVal = chart.test(argc, argv, 25.0);
#ifdef vtkCharts_USE_QT
  if (retVal == vtkCharts::BaseChart::INTERACT)
    application.exec();
#endif

  return !retVal;
}
