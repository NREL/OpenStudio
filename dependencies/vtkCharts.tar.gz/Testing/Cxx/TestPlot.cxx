#include <iostream>
#include <vector>
#include <string>

#include "Chart.h"
#include "Plot.h"
#include "Axis.h"
#include "Color.h"
#include "Legend.h"

#ifdef vtkCharts_USE_QT
# include <QApplication>
# include <QWidget>
#endif

#include <cmath>

#define NUM_POINTS (69)

int TestPlot(int argc, char *argv [])
{
#ifdef vtkCharts_USE_QT
  QApplication application(argc, argv);
#endif

  std::vector<float> x_floats(NUM_POINTS);
  std::vector<float> cosine(NUM_POINTS);
  std::vector<float> sine(NUM_POINTS);
  std::vector<float> offset_sine(NUM_POINTS);

  float inc = 7.5 / (NUM_POINTS-1);
  for (int i = 0; i < NUM_POINTS; ++i)
    {
    x_floats.push_back(i * inc);
    cosine.push_back(cos(i * inc) + 0.0);
    sine.push_back(sin(i * inc) + 0.0);
    offset_sine.push_back(sin(i * inc) + 0.5);
    }

  vtkCharts::Chart chart(x_floats, cosine, "Cosine");

  vtkCharts::Plot sinePlot = chart.addPlot(x_floats, sine, "Sine");
  vtkCharts::Plot offsetSinePlot = chart.addPlot(x_floats, offset_sine,
                                                 "Offset Sine");

  sinePlot.setLineStyle(vtkCharts::Plot::DOTTED);
  offsetSinePlot.setLineStyle(vtkCharts::Plot::PATTERN_1);
  offsetSinePlot.setMarkerStyle(vtkCharts::Plot::CROSS);
  offsetSinePlot.setMarkerSize(20);

  std::vector<vtkCharts::Color3ub> colors;
  colors.push_back(vtkCharts::Color3ub(255,0,0));
  colors.push_back(vtkCharts::Color3ub(0,255,0));
  colors.push_back(vtkCharts::Color3ub(0,0,255));
  chart.setColors(colors);

  // Now change out a color for one of the plots
  offsetSinePlot.setColor(vtkCharts::Color4ub(200, 10, 255));

  chart.axis(vtkCharts::Axis::LEFT).setTitle("My axis title!");
  chart.axis(vtkCharts::Axis::BOTTOM).setTitle("My other axis title...");
  chart.axis(vtkCharts::Axis::BOTTOM).setNumberOfTicks(3);
  chart.axis(vtkCharts::Axis::BOTTOM).setNotation(vtkCharts::Axis::MIXED);
  chart.axis(vtkCharts::Axis::BOTTOM).setPrecision(4);

  chart.setShowLegend(true);
  chart.legend().setVerticalAlignment(vtkCharts::Legend::BOTTOM);
  chart.legend().setHorizontalAlignment(vtkCharts::Legend::LEFT);
  chart.legend().setInline(false);

  vtkCharts::BaseChart::TestReturn retVal = chart.test(argc, argv, 25.0);
#ifdef vtkCharts_USE_QT
  chart.chartProxy();
  if (retVal == vtkCharts::BaseChart::INTERACT)
    application.exec();
#endif

  if (!chart.plot("Sine").isValid())
    {
    std::cout << "Sine should be valid, but was not." << std::endl;
    return 1;
    }
  if (chart.plot("I am not a plot").isValid())
    {
    std::cout << "'I am not a plot' should not be valid, but was." << std::endl;
    return 1;
    }

  return !retVal;
}
