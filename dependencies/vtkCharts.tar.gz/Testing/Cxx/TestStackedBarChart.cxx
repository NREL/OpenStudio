#include <iostream>
#include <vector>
#include <string>

#include "BarChart.h"
#include "Color.h"

#include "vtkDataArray.h"

#ifdef vtkCharts_USE_QT
# include <QApplication>
# include <QWidget>
#endif

namespace Baseline {
  float Interior_Equipment__elec_[5] = {35.82,35.82,35.82,35.82,35.82};
  float Interior_Equipment__gas_[5] = {9.01,9.01,9.01,9.01,9.01};
  float Interior_Lighting__elec_[5] = {34.85,34.85,34.85,34.85,34.85};
  float Heating__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
  float Heating__gas_[5] = {53.47,76.93,85.07,86.43,78.33};
  float Cooling__elec_[5] = {76.53,66.52,53.72,54.94,38.05};
  float Fans__elec_[5] = {30.89,31.40,33.53,30.61,33.59};
  float Water_Systems__gas_[5] = {8.35,10.03,9.06,11.33,10.89};
  float Pumps__elec_[5] = {1.65,1.63,1.67,1.60,1.53};
  float Humidification__elec_[5] = {0.20,3.06,23.46,7.54,41.01};
  float Heat_Rejection__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
}

namespace Step1 {
  float Interior_Equipment__elec_[5] = {35.82,35.82,35.82,35.82,35.82};
  float Interior_Equipment__gas_[5] = {9.01,9.01,9.01,9.01,9.01};
  float Interior_Lighting__elec_[5] = {34.85,34.85,34.85,34.85,34.85};
  float Heating__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
  float Heating__gas_[5] = {42.32,57.62,63.07,69.37,60.84};
  float Cooling__elec_[5] = {68.79,58.44,45.50,48.81,33.06};
  float Fans__elec_[5] = {27.72,27.58,28.55,27.39,29.44};
  float Water_Systems__gas_[5] = {8.35,10.03,9.06,11.33,10.89};
  float Pumps__elec_[5] = {1.50,1.49,1.48,1.48,1.39};
  float Humidification__elec_[5] = {0.16,2.51,19.53,6.44,36.55};
  float Heat_Rejection__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
}

namespace Step2 {
  float Interior_Equipment__elec_[5] = {35.82,35.82,35.82,35.82,35.82};
  float Interior_Equipment__gas_[5] = {9.01,9.01,9.01,9.01,9.01};
  float Interior_Lighting__elec_[5] = {16.40,16.40,16.40,16.40,16.40};
  float Heating__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
  float Heating__gas_[5] = {46.60,61.26,65.92,72.70,62.86};
  float Cooling__elec_[5] = {62.86,53.27,41.22,44.28,29.54};
  float Fans__elec_[5] = {24.89,24.82,25.60,24.66,26.07};
  float Water_Systems__gas_[5] = {8.35,10.03,9.06,11.33,10.89};
  float Pumps__elec_[5] = {1.35,1.34,1.33,1.34,1.23};
  float Humidification__elec_[5] = {0.13,2.09,17.39,5.54,33.14};
  float Heat_Rejection__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
}

namespace Step3 {
  float Interior_Equipment__elec_[5] = {35.82,35.82,35.82,35.82,35.82};
  float Interior_Equipment__gas_[5] = {9.01,9.01,9.01,9.01,9.01};
  float Interior_Lighting__elec_[5] = {14.28,14.30,14.33,14.33,14.33};
  float Heating__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
  float Heating__gas_[5] = {45.74,60.46,65.04,71.86,61.91};
  float Cooling__elec_[5] = {61.73,52.32,40.45,43.44,28.92};
  float Fans__elec_[5] = {24.45,24.40,25.17,24.25,25.58};
  float Water_Systems__gas_[5] = {8.35,10.03,9.06,11.33,10.89};
  float Pumps__elec_[5] = {1.32,1.32,1.31,1.31,1.21};
  float Humidification__elec_[5] = {0.13,2.04,17.07,5.43,32.59};
  float Heat_Rejection__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
}

namespace Step4 {
  float Interior_Equipment__elec_[5] = {35.82,35.82,35.82,35.82,35.82};
  float Interior_Equipment__gas_[5] = {9.01,9.01,9.01,9.01,9.01};
  float Interior_Lighting__elec_[5] = {14.28,14.30,14.33,14.33,14.33};
  float Heating__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
  float Heating__gas_[5] = {47.16,61.42,65.51,72.44,62.39};
  float Cooling__elec_[5] = {61.13,51.64,39.70,42.69,28.29};
  float Fans__elec_[5] = {20.89,20.85,21.51,20.72,21.88};
  float Water_Systems__gas_[5] = {8.35,10.03,9.06,11.33,10.89};
  float Pumps__elec_[5] = {1.32,1.32,1.31,1.31,1.21};
  float Humidification__elec_[5] = {0.13,2.01,16.83,5.37,32.09};
  float Heat_Rejection__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
}

namespace Step5 {
  float Interior_Equipment__elec_[5] = {35.82,35.82,35.82,35.82,35.82};
  float Interior_Equipment__gas_[5] = {9.01,9.01,9.01,9.01,9.01};
  float Interior_Lighting__elec_[5] = {14.28,14.30,14.33,14.33,14.33};
  float Heating__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
  float Heating__gas_[5] = {34.82,47.15,50.38,56.73,48.38};
  float Cooling__elec_[5] = {61.13,51.64,39.70,42.69,28.29};
  float Fans__elec_[5] = {20.89,20.85,21.51,20.72,21.88};
  float Water_Systems__gas_[5] = {7.42,8.92,8.05,10.07,9.68};
  float Pumps__elec_[5] = {1.32,1.32,1.31,1.31,1.21};
  float Humidification__elec_[5] = {0.13,2.01,16.83,5.37,32.09};
  float Heat_Rejection__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
}

namespace Step6 {
  float Interior_Equipment__elec_[5] = {35.82,35.82,35.82,35.82,35.82};
  float Interior_Equipment__gas_[5] = {9.01,9.01,9.01,9.01,9.01};
  float Interior_Lighting__elec_[5] = {14.28,14.30,14.33,14.33,14.33};
  float Heating__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
  float Heating__gas_[5] = {34.82,47.15,50.38,56.73,48.38};
  float Cooling__elec_[5] = {53.67,45.34,34.86,37.48,24.84};
  float Fans__elec_[5] = {20.89,20.85,21.51,20.72,21.88};
  float Water_Systems__gas_[5] = {7.42,8.92,8.05,10.07,9.68};
  float Pumps__elec_[5] = {1.32,1.32,1.31,1.31,1.21};
  float Humidification__elec_[5] = {0.13,2.01,16.83,5.37,32.09};
  float Heat_Rejection__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
}

namespace Step7 {
  float Interior_Equipment__elec_[5] = {35.82,35.82,35.82,35.82,35.82};
  float Interior_Equipment__gas_[5] = {9.01,9.01,9.01,9.01,9.01};
  float Interior_Lighting__elec_[5] = {14.28,14.30,14.33,14.33,14.33};
  float Heating__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
  float Heating__gas_[5] = {21.67,33.00,33.06,41.66,32.20};
  float Cooling__elec_[5] = {48.35,40.91,30.81,33.69,21.92};
  float Fans__elec_[5] = {16.29,16.22,16.29,16.09,16.46};
  float Water_Systems__gas_[5] = {7.43,8.92,8.05,10.07,9.68};
  float Pumps__elec_[5] = {1.32,1.32,1.31,1.31,1.21};
  float Humidification__elec_[5] = {0.11,1.59,13.34,4.15,25.35};
  float Heat_Rejection__elec_[5] = {0.00,0.00,0.00,0.00,0.00};
}

std::vector<float> Vectorize(float a[5])
{
  return std::vector<float>(a, a+5);
}


int TestStackedBarChart(int argc, char *argv [])
{
#ifdef vtkCharts_USE_QT
  QApplication application(argc, argv);
#endif

  std::vector<vtkCharts::Color3ub> colors;
  colors.push_back(vtkCharts::Color3ub(0,176,80));
  colors.push_back(vtkCharts::Color3ub(146,139,87));
  colors.push_back(vtkCharts::Color3ub(255,253,3));
  colors.push_back(vtkCharts::Color3ub(192,0,0));
  colors.push_back(vtkCharts::Color3ub(189,0,6));
  colors.push_back(vtkCharts::Color3ub(0,113,191));
  colors.push_back(vtkCharts::Color3ub(114,47,160));
  colors.push_back(vtkCharts::Color3ub(156,219,79));
  colors.push_back(vtkCharts::Color3ub(255,186,0));
  colors.push_back(vtkCharts::Color3ub(11,165,237));

  std::string baseline("Baseline");
  vtkCharts::BarChart chart("Baseline");

  chart.setColors(colors);
  chart.stackSeries(Vectorize(Baseline::Interior_Equipment__elec_), baseline,
                    "Interior Equipment (elec)");
  chart.stackSeries(Vectorize(Baseline::Interior_Equipment__gas_), baseline,
                    "Interior Equipment (gas)");
  chart.stackSeries(Vectorize(Baseline::Interior_Lighting__elec_), baseline,
                    "Interior Lighting (elec)");
  chart.stackSeries(Vectorize(Baseline::Heating__elec_), baseline,
                    "Heating (elec)");
  chart.stackSeries(Vectorize(Baseline::Heating__gas_), baseline,
                    "Heating (gas)");
  chart.stackSeries(Vectorize(Baseline::Cooling__elec_), baseline,
                    "Cooling (elec)");
  chart.stackSeries(Vectorize(Baseline::Fans__elec_), baseline,
                    "Fans (elec)");
  chart.stackSeries(Vectorize(Baseline::Water_Systems__gas_), baseline,
                    "Water Systems (gas)");
  chart.stackSeries(Vectorize(Baseline::Pumps__elec_), baseline,
                    "Pumps (elec)");
  chart.stackSeries(Vectorize(Baseline::Humidification__elec_), baseline,
                    "Humidification (elec)");
  chart.stackSeries(Vectorize(Baseline::Heat_Rejection__elec_), baseline,
                    "Heat Rejection (elec)");

  std::string step1("Step 1");
  chart.stackSeries(Vectorize(Step1::Interior_Equipment__elec_), step1,
                    "Interior Equipment (elec)");
  chart.stackSeries(Vectorize(Step1::Interior_Equipment__gas_), step1,
                    "Interior Equipment (gas)");
  chart.stackSeries(Vectorize(Step1::Interior_Lighting__elec_), step1,
                    "Interior Lighting (elec)");
  chart.stackSeries(Vectorize(Step1::Heating__elec_), step1,
                    "Heating (elec)");
  chart.stackSeries(Vectorize(Step1::Heating__gas_), step1,
                    "Heating (gas)");
  chart.stackSeries(Vectorize(Step1::Cooling__elec_), step1,
                    "Cooling (elec)");
  chart.stackSeries(Vectorize(Step1::Fans__elec_), step1,
                    "Fans (elec)");
  chart.stackSeries(Vectorize(Step1::Water_Systems__gas_), step1,
                    "Water Systems (gas)");
  chart.stackSeries(Vectorize(Step1::Pumps__elec_), step1,
                    "Pumps (elec)");
  chart.stackSeries(Vectorize(Step1::Humidification__elec_), step1,
                    "Humidification (elec)");
  chart.stackSeries(Vectorize(Step1::Heat_Rejection__elec_), step1,
                    "Heat Rejection (elec)");

  std::string step2("Step 2");
  chart.stackSeries(Vectorize(Step2::Interior_Equipment__elec_), step2,
                    "Interior Equipment (elec)");
  chart.stackSeries(Vectorize(Step2::Interior_Equipment__gas_), step2,
                    "Interior Equipment (gas)");
  chart.stackSeries(Vectorize(Step2::Interior_Lighting__elec_), step2,
                    "Interior Lighting (elec)");
  chart.stackSeries(Vectorize(Step2::Heating__elec_), step2,
                    "Heating (elec)");
  chart.stackSeries(Vectorize(Step2::Heating__gas_), step2,
                    "Heating (gas)");
  chart.stackSeries(Vectorize(Step2::Cooling__elec_), step2,
                    "Cooling (elec)");
  chart.stackSeries(Vectorize(Step2::Fans__elec_), step2,
                    "Fans (elec)");
  chart.stackSeries(Vectorize(Step2::Water_Systems__gas_), step2,
                    "Water Systems (gas)");
  chart.stackSeries(Vectorize(Step2::Pumps__elec_), step2,
                    "Pumps (elec)");
  chart.stackSeries(Vectorize(Step2::Humidification__elec_), step2,
                    "Humidification (elec)");
  chart.stackSeries(Vectorize(Step2::Heat_Rejection__elec_), step2,
                    "Heat Rejection (elec)");

  std::string step3("Step 3");
  chart.stackSeries(Vectorize(Step3::Interior_Equipment__elec_), step3,
                    "Interior Equipment (elec)");
  chart.stackSeries(Vectorize(Step3::Interior_Equipment__gas_), step3,
                    "Interior Equipment (gas)");
  chart.stackSeries(Vectorize(Step3::Interior_Lighting__elec_), step3,
                    "Interior Lighting (elec)");
  chart.stackSeries(Vectorize(Step3::Heating__elec_), step3,
                    "Heating (elec)");
  chart.stackSeries(Vectorize(Step3::Heating__gas_), step3,
                    "Heating (gas)");
  chart.stackSeries(Vectorize(Step3::Cooling__elec_), step3,
                    "Cooling (elec)");
  chart.stackSeries(Vectorize(Step3::Fans__elec_), step3,
                    "Fans (elec)");
  chart.stackSeries(Vectorize(Step3::Water_Systems__gas_), step3,
                    "Water Systems (gas)");
  chart.stackSeries(Vectorize(Step3::Pumps__elec_), step3,
                    "Pumps (elec)");
  chart.stackSeries(Vectorize(Step3::Humidification__elec_), step3,
                    "Humidification (elec)");
  chart.stackSeries(Vectorize(Step3::Heat_Rejection__elec_), step3,
                    "Heat Rejection (elec)");

  std::string step4("Step 4");
  chart.stackSeries(Vectorize(Step4::Interior_Equipment__elec_), step4,
                    "Interior Equipment (elec)");
  chart.stackSeries(Vectorize(Step4::Interior_Equipment__gas_), step4,
                    "Interior Equipment (gas)");
  chart.stackSeries(Vectorize(Step4::Interior_Lighting__elec_), step4,
                    "Interior Lighting (elec)");
  chart.stackSeries(Vectorize(Step4::Heating__elec_), step4,
                    "Heating (elec)");
  chart.stackSeries(Vectorize(Step4::Heating__gas_), step4,
                    "Heating (gas)");
  chart.stackSeries(Vectorize(Step4::Cooling__elec_), step4,
                    "Cooling (elec)");
  chart.stackSeries(Vectorize(Step4::Fans__elec_), step4,
                    "Fans (elec)");
  chart.stackSeries(Vectorize(Step4::Water_Systems__gas_), step4,
                    "Water Systems (gas)");
  chart.stackSeries(Vectorize(Step4::Pumps__elec_), step4,
                    "Pumps (elec)");
  chart.stackSeries(Vectorize(Step4::Humidification__elec_), step4,
                    "Humidification (elec)");
  chart.stackSeries(Vectorize(Step4::Heat_Rejection__elec_), step4,
                    "Heat Rejection (elec)");

  std::string step5("Step 5");
  chart.stackSeries(Vectorize(Step5::Interior_Equipment__elec_), step5,
                    "Interior Equipment (elec)");
  chart.stackSeries(Vectorize(Step5::Interior_Equipment__gas_), step5,
                    "Interior Equipment (gas)");
  chart.stackSeries(Vectorize(Step5::Interior_Lighting__elec_), step5,
                    "Interior Lighting (elec)");
  chart.stackSeries(Vectorize(Step5::Heating__elec_), step5,
                    "Heating (elec)");
  chart.stackSeries(Vectorize(Step5::Heating__gas_), step5,
                    "Heating (gas)");
  chart.stackSeries(Vectorize(Step5::Cooling__elec_), step5,
                    "Cooling (elec)");
  chart.stackSeries(Vectorize(Step5::Fans__elec_), step5,
                    "Fans (elec)");
  chart.stackSeries(Vectorize(Step5::Water_Systems__gas_), step5,
                    "Water Systems (gas)");
  chart.stackSeries(Vectorize(Step5::Pumps__elec_), step5,
                    "Pumps (elec)");
  chart.stackSeries(Vectorize(Step5::Humidification__elec_), step5,
                    "Humidification (elec)");
  chart.stackSeries(Vectorize(Step5::Heat_Rejection__elec_), step5,
                    "Heat Rejection (elec)");

  std::string step6("Step 6");
  chart.stackSeries(Vectorize(Step6::Interior_Equipment__elec_), step6,
                    "Interior Equipment (elec)");
  chart.stackSeries(Vectorize(Step6::Interior_Equipment__gas_), step6,
                    "Interior Equipment (gas)");
  chart.stackSeries(Vectorize(Step6::Interior_Lighting__elec_), step6,
                    "Interior Lighting (elec)");
  chart.stackSeries(Vectorize(Step6::Heating__elec_), step6,
                    "Heating (elec)");
  chart.stackSeries(Vectorize(Step6::Heating__gas_), step6,
                    "Heating (gas)");
  chart.stackSeries(Vectorize(Step6::Cooling__elec_), step6,
                    "Cooling (elec)");
  chart.stackSeries(Vectorize(Step6::Fans__elec_), step6,
                    "Fans (elec)");
  chart.stackSeries(Vectorize(Step6::Water_Systems__gas_), step6,
                    "Water Systems (gas)");
  chart.stackSeries(Vectorize(Step6::Pumps__elec_), step6,
                    "Pumps (elec)");
  chart.stackSeries(Vectorize(Step6::Humidification__elec_), step6,
                    "Humidification (elec)");
  chart.stackSeries(Vectorize(Step6::Heat_Rejection__elec_), step6,
                    "Heat Rejection (elec)");

  std::string step7("Step 7");
  chart.stackSeries(Vectorize(Step7::Interior_Equipment__elec_), step7,
                    "Interior Equipment (elec)");
  chart.stackSeries(Vectorize(Step7::Interior_Equipment__gas_), step7,
                    "Interior Equipment (gas)");
  chart.stackSeries(Vectorize(Step7::Interior_Lighting__elec_), step7,
                    "Interior Lighting (elec)");
  chart.stackSeries(Vectorize(Step7::Heating__elec_), step7,
                    "Heating (elec)");
  chart.stackSeries(Vectorize(Step7::Heating__gas_), step7,
                    "Heating (gas)");
  chart.stackSeries(Vectorize(Step7::Cooling__elec_), step7,
                    "Cooling (elec)");
  chart.stackSeries(Vectorize(Step7::Fans__elec_), step7,
                    "Fans (elec)");
  chart.stackSeries(Vectorize(Step7::Water_Systems__gas_), step7,
                    "Water Systems (gas)");
  chart.stackSeries(Vectorize(Step7::Pumps__elec_), step7,
                    "Pumps (elec)");
  chart.stackSeries(Vectorize(Step7::Humidification__elec_), step7,
                    "Humidification (elec)");
  chart.stackSeries(Vectorize(Step7::Heat_Rejection__elec_), step7,
                    "Heat Rejection (elec)");

  //chart.SetTitle(std::string(""));
  chart.axis(vtkCharts::Axis::LEFT)
      .setTitle("Annual Energy End Use Intensity (kBtu/ft^2)");
  chart.axis(vtkCharts::Axis::BOTTOM)
      .setTitle("");

  std::vector<std::string> labels(5);
  labels[0] = "1A-Miami";
  labels[1] = "2A-Houston";
  labels[2] = "2B-Phoenix";
  labels[3] = "3A-Memphis";
  labels[4] = "3A-El Paso";
  chart.setXTickLabels(labels);
  chart.axis(vtkCharts::Axis::LEFT).setRange(0.0, 300.0);
  chart.setSize(1050, 1050);

  chart.setShowLegend(true);

  vtkCharts::BarChart::TestReturn retVal = chart.test(argc, argv, 25.0);
#ifdef vtkCharts_USE_QT
  if (retVal == vtkCharts::BarChart::INTERACT)
    application.exec();
#endif

  return !retVal;
}
