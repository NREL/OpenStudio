#include <iostream>
#include <string>

#include "FloodPlot.h"
#include "Matrix.h"

#include "vtkMath.h"

#ifdef vtkCharts_USE_QT
# include <QApplication>
# include <QWidget>
#endif

int TestFloodPlot(int argc, char *argv[])
{
#ifdef vtkCharts_USE_QT
  QApplication application(argc, argv);
#endif

  vtkCharts::Matrixf m(400, 200);
  for (int i = 0; i < 400; ++i)
    {
    for (int j = 0; j < 200; ++j)
      {
      m(i, j) = sin(vtkMath::RadiansFromDegrees(double(2*i))) *
          cos(vtkMath::RadiansFromDegrees(double(j)));
      }
    }

  vtkCharts::FloodPlot chart(m, 0.0, 100.0, 0.0, 50.0 ,std::string("Me"));

  chart.setTitle("Test Chart");
  chart.axis(vtkCharts::Axis::BOTTOM).setTitle("X");
  chart.axis(vtkCharts::Axis::LEFT).setTitle("Y");

  vtkCharts::FloodPlot::TestReturn retVal = chart.test(argc, argv, 25.0);
#ifdef vtkCharts_USE_QT
  if (retVal == vtkCharts::BaseChart::INTERACT)
    application.exec();
#endif

  return !retVal;
}
