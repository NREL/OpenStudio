#include <iostream>
#include <vector>
#include <string>

#include "Chart.h"
#include "Plot.h"
#include "Axis.h"
#include "Color.h"

#ifdef vtkCharts_USE_QT
#include <QApplication>
#include <QWidget>
#endif

#include <math.h>


#define NUM_POINTS (69)

int TestPlotMinMax(int argc, char *argv [])
{
#ifdef vtkCharts_USE_QT
  QApplication application(argc,argv);
#endif

  std::vector<float> x_floats(NUM_POINTS);
  std::vector<float> cosine(NUM_POINTS);
  std::vector<float> sine(NUM_POINTS);
  std::vector<float> offset_sine(NUM_POINTS);

  float inc = 7.5 / (NUM_POINTS-1);
  for (int i = 0; i < NUM_POINTS; i++)
    {
    x_floats.push_back(i * inc);
    cosine.push_back(cos(i * inc) + 0.0);
    sine.push_back(sin(i * inc) + 0.0);
    offset_sine.push_back(sin(i * inc) + 0.5);
    }

  vtkCharts::Chart chart(x_floats, cosine, "Cosine");

  vtkCharts::Plot sinePlot = chart.addPlot(x_floats, sine, "Sine");
  vtkCharts::Plot offsetSinePlot= chart.addPlot(x_floats, offset_sine,
                                                "Offset Sine");

  sinePlot.setLineStyle(vtkCharts::Plot::DOTTED);
  offsetSinePlot.setLineStyle(vtkCharts::Plot::PATTERN_1);

  chart.axis(vtkCharts::Axis::BOTTOM).setMinimum(2.0);
  chart.axis(vtkCharts::Axis::BOTTOM).setMaximum(6.0);
  chart.axis(vtkCharts::Axis::LEFT).setMinimum(-0.5);
  chart.axis(vtkCharts::Axis::LEFT).setMaximum(0.5);

  std::vector<vtkCharts::Color3ub> colors;
  colors.push_back(vtkCharts::Color3ub(255,0,0));
  colors.push_back(vtkCharts::Color3ub(0,255,0));
  colors.push_back(vtkCharts::Color3ub(0,0,255));
  chart.setColors(colors);

  vtkCharts::BaseChart::TestReturn retVal = chart.test(argc,argv,25.0);
#ifdef vtkCharts_USE_QT
  if (retVal == vtkCharts::BaseChart::INTERACT)
    application.exec();
#endif

  return !retVal;
}

