#include <iostream>
#include <vector>

#include "Matrix.h"

int TestMatrix(int argc, char *argv [])
{
  bool error = false;
  vtkCharts::Matrix<int> m(2, 2);

  m(0, 0) = 1;
  m(0, 1) = 2;
  m(1, 0) = 3;
  m(1, 1) = 4;

  std::cout << "m:\t" << m(0, 0) << "\t" << m(0, 1)
            << "\n\t" << m(1, 0) << "\t" << m(1, 1) << std::endl;

  if (m(0, 0) != 1 || m(0, 1) != 2 || m(1, 0) != 3 || m(1, 1) != 4)
    {
    std::cout << "Error - one of the matrix values was incorrect." << std::endl;
    error = true;
    }

  vtkCharts::Matrixf mi(3, 3);
  int v = 0;
  for (int i = 0; i < 3; ++i)
    {
    for (int j = 0; j < 3; ++j)
      {
      mi(i, j) = v++;
      }
    }
  v = 0;
  for (int i = 0; i < 3; ++i)
    {
    for (int j = 0; j < 3; ++j)
      {
      if (mi(i, j) != v++)
        {
        error = true;
        std::cout << "Error: (" << i << ", " << j
                  << ") does not match input. Expected "
                  << (v - 1) << " but got " << mi(i, j) << std::endl;
        }
      }
    }
  // Now test resizing.
  mi.Resize(2, 2);
  v = 0;
    for (int i = 0; i < 2; ++i)
      {
      for (int j = 0; j < 2; ++j)
        {
        mi(i, j) = v++;
        }
      }
  v = 0;
  for (int i = 0; i < 2; ++i)
    {
    for (int j = 0; j < 2; ++j)
      {
      if (mi(i, j) != v++)
        {
        error = true;
        std::cout << "Error: (" << i << ", " << j
                  << ") does not match input. Expected "
                  << (v - 1) << " but got " << mi(i, j) << std::endl;
        }
      }
    }
  std::cout << "mi:\t" << mi(0, 0) << "\t" << mi(0, 1)
            << "\n\t" << mi(1, 0) << "\t" << mi(1, 1) << std::endl;

  return error ? 1 : 0;
}

