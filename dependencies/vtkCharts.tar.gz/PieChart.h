/*=========================================================================

  Program:   vtkCharts
  Module:    PieChart.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsPieChart_h
#define __vtkChartsPieChart_h

#include "BaseChart.h"

#include <vector>
#include <string>

namespace vtkCharts {

/*! @brief A basic pie chart.
 */
class PieChart : public BaseChart
{
public:
  /*! @brief Construct a basic PieChart.
   *
   * @param series The data sereis to display in the PieChart.
   */
  PieChart(const std::vector<float>& series);
  ~PieChart();

  /*! @brief Replace the current series with a new series.
   *
   * @param series The new series to display.
   */
  void setSeries(const std::vector<float>& series);

  /*! @brief Set the labels for each element in the series (and thus each wedge
   * in the Pie).
   *
   * @param labels The labels to use for each wedge in the PieChart.
   */
  void setWedgeLabels(const std::vector<std::string>& labels);
};

}

#endif
