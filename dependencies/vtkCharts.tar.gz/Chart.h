/*=========================================================================

  Program:   vtkCharts
  Module:    Chart.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsChart_h
#define __vtkChartsChart_h

#include "BaseChart.h"

#include <vector>
#include <string>

class vtkChartXY;

namespace vtkCharts {

class Color3ub;
class Plot;
class QChartProxy;

/*! @brief Implements a basic XY chart.
 */
class Chart : public BaseChart
{
public:
  /*! @brief Construct an XY chart. */
  Chart();
  Chart(const std::vector<float>& x, const std::vector<float>& y,
        const std::string& seriesName);

  virtual ~Chart();

  /*! @brief Set the colors to be used for the plots as they are added to the
   * Chart. These colors will be applied to all current plots in the chart.
   *
   * @param colors A std::vector of Color3ub to apply to the chart.
   */
  void setColors(const std::vector<Color3ub>& colors);

  /*! @brief Add a new plot to the Chart.
   *
   * @param x X component of the data series to start with.  Must have the same
   * size as y.
   * @param y Y component of the data series to start with.  Must have the same
   * size as x.
   * @param seriesName The name of this series.  This will be the legend name.
   *
   * @return A plot object where you can set further parameters on the plot.
   */
  Plot addPlot(const std::vector<float>& x, const std::vector<float>& y,
               const std::string& seriesName);

  /*! @brief Get the plot with the supplied name.
   *
   * @param seriesName The name of the series in the chart.
   * @return Plot object, check isValid() to be certain the plot with the
   * supplied name exists.
   */
  Plot plot(const std::string& seriesName);

  /*! @brief Should the chart automatically adjust axis visibility?
   *
   * If set to true, the chart will only display axes which have plots
   * associated with them. Default is true.
   */
  void setAutoAxes(bool val);

  /*! @brief True if axis visibility will be adjusted automatically (default).
   */
  bool autoAxes() const;

  /*! @brief Return the Qt proxy object. This object provides a proxy that will
   * emit Qt signals, and has Qt slots that can be connected to.
   *
   * @return A QChartProxy object, with relevant signals and slots. Will return
   * null if Qt is not enabled.
   */
  vtkCharts::QChartProxy * chartProxy();

  /*! @brief Return the vtkChartXY object. This object provides a access
   * to the underlying VTK object that is being used to contain the chart.
   *
   * @return The underlying vtkChartXY object.
   */
  vtkChartXY * chartObject() const;
};

}

#endif
