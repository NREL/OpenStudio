/*=========================================================================

  Program:   vtkCharts
  Module:    vtkChartsVector.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#ifndef __vtkChartsVector_h
#define __vtkChartsVector_h

namespace vtkCharts {

/*!
 * @brief Templated base type for storage of vectors.
 *
 * This class is a templated data type for storing and manipulating fixed size
 * vectors, which can be used to represent two and three dimensional points. The
 * memory layout is a contiguous array of the specified type, such that a
 * float[2] can be cast to a vtkCharts::Vector2f and manipulated.
 * Also a float[6] could be cast and used as a vtkCharts::Vector2f[3].
 *
 * Note also that as a result of the above vtkCharts::Vector is explicitly
 * castable to a vtkVector in VTK.
*/
template<typename T, int Size>
class Vector
{
public:
  Vector()
  {
    for (int i = 0; i < Size; ++i)
      {
      Data[i] = 0;
      }
  }

  Vector(const T* init)
  {
    for (int i = 0; i < Size; ++i)
      {
      Data[i] = init[i];
      }
  }

  /*! @brief Get the size of the vtkVector.
   */
  int GetSize() const { return Size; }

  /*! @brief Get a pointer to the underlying data of the vtkVector.
   */
  T* GetData() { return this->Data; }
  const T* GetData() const { return this->Data; }

  /*! @brief  Get a reference to the underlying data element of the vtkVector.
   * Can be used in much the same way as vector[i] is used.
   */
  T& operator[](int i) { return this->Data[i]; }
  const T& operator[](int i) const { return this->Data[i]; }

  /*! @brief Get the value of the vector at the index speciifed.
   *
   * Does bounds checking, used in much the same way as vector.at(i) is used.
   */
  T operator()(int i) const { return this->Data[i]; }

protected:
  T Data[Size];
};

/*! @brief  templated base type for storage of 2D vectors.
 */
template<typename T>
class Vector2 : public Vector<T, 2>
{
public:
  Vector2(const T& x = 0.0, const T& y = 0.0)
  {
    this->Data[0] = x;
    this->Data[1] = y;
  }

  Vector2(const T* init) : Vector<T, 2>(init)
  {
  }

  /*! @brief Set the x and y components of the vector.
   */
  void Set(const T& x, const T& y)
  {
    this->Data[0] = x;
    this->Data[1] = y;
  }

  /*! @brief Set the x component of the vector, i.e. element 0.
   */
  void SetX(const T& x) { this->Data[0] = x; }

  /*! @brief // Get the x component of the vector, i.e. element 0.
   */
  const T& GetX() const { return this->Data[0]; }
  const T& X() const { return this->Data[0]; }

  /*! @brief Set the y component of the vector, i.e. element 1.
   */
  void SetY(const T& y) { this->Data[1] = y; }

  /*! @brief Get the y component of the vector, i.e. element 1.
   */
  const T& GetY() const { return this->Data[1]; }
  const T& Y() const { return this->Data[1]; }
};

/*! @brief templated base type for storage of 3D vectors.
 */
template<typename T>
class Vector3 : public Vector<T, 3>
{
public:
  Vector3(const T& x = 0.0, const T& y = 0.0, const T& z = 0.0)
  {
    this->Data[0] = x;
    this->Data[1] = y;
    this->Data[2] = z;
  }

  Vector3(const T* init) : Vector<T, 3>(init)
  {
  }

  /*! @brief Set the x, y and z components of the vector.
   */
  void Set(const T& x, const T& y, const T& z)
  {
    this->Data[0] = x;
    this->Data[1] = y;
    this->Data[2] = z;
  }

  /*! @brief Set the x component of the vector, i.e. element 0.
   */
  void SetX(const T& x) { this->Data[0] = x; }

  /*! @brief Get the x component of the vector, i.e. element 0.
   */
  const T& GetX() const { return this->Data[0]; }
  const T& X() const { return this->Data[0]; }

  /*! @brief Set the y component of the vector, i.e. element 1.
   */
  void SetY(const T& y) { this->Data[1] = y; }

  /*! @brief Get the y component of the vector, i.e. element 1.
   */
  const T& GetY() const { return this->Data[1]; }
  const T& Y() const { return this->Data[1]; }

  /*! @brief Set the z component of the vector, i.e. element 2.
   */
  void SetZ(const T& z) { this->Data[2] = z; }

  /*! @brief Get the z component of the vector, i.e. element 2.
   */
  const T& GetZ() const { return this->Data[2]; }
  const T& Z() const { return this->Data[2]; }

};

/*! @brief Templated base type for storage of 2D rectangles.
*/
template<typename T>
class Rect : public Vector<T, 4>
{
public:
  Rect(const T& x = 0.0, const T& y = 0.0, const T width = 0.0,
          const T& height = 0.0 )
  {
    this->Data[0] = x;
    this->Data[1] = y;
    this->Data[2] = width;
    this->Data[3] = height;
  }

  Rect(const T* init) : Vector<T, 4>(init)
  {
  }

  /*! @brief Set the x, y components of the rectangle, and the width/height.
   */
  void Set(const T& x, const T& y, const T& width, const T& height)
  {
    this->Data[0] = x;
    this->Data[1] = y;
    this->Data[2] = width;
    this->Data[3] = height;
  }

  /*! @brief Set the x component of the rectangle bottom corner, i.e. element 0.
   */
  void SetX(const T& x) { this->Data[0] = x; }

  /*! @brief Get the x component of the rectangle bottom corner, i.e. element 0.
   */
  const T& GetX() const { return this->Data[0]; }
  const T& X() const { return this->Data[0]; }

  /*! @brief Set the y component of the rectangle bottom corner, i.e. element 1.
   */
  void SetY(const T& y) { this->Data[1] = y; }

  /*! @brief Get the y component of the rectangle bottom corner, i.e. element 1.
   */
  const T& GetY() const { return this->Data[1]; }
  const T& Y() const { return this->Data[1]; }

  /*! @brief Set the width of the rectanle, i.e. element 2.
   */
  void SetWidth(const T& width) { this->Data[2] = width; }

  /*! @brief Get the width of the rectangle, i.e. element 2.
   */
  const T& GetWidth() const { return this->Data[2]; }
  const T& Width() const { return this->Data[2]; }

  /*!  @brief Set the height of the rectangle, i.e. element 3.
   */
  void SetHeight(const T& height) { this->Data[3] = height; }

  /*! @brief Get the height of the rectangle, i.e. element 3.
   */
  const T& GetHeight() const { return this->Data[3]; }
  const T& Height() const { return this->Data[3]; }

};

class Vector2i : public Vector2<int>
{
public:
  Vector2i(int x = 0, int y = 0) : Vector2<int>(x, y) {}
  Vector2i(const int* i) : Vector2<int>(i) {}
};

class Vector2f : public Vector2<float>
{
public:
  Vector2f(float x = 0.0, float y = 0.0) : Vector2<float>(x, y) {}
  Vector2f(const float* i) : Vector2<float>(i) {}
};

class Vector2d : public Vector2<double>
{
public:
  Vector2d(double x = 0.0, double y = 0.0) : Vector2<double>(x, y) {}
  Vector2d(const double* i) : Vector2<double>(i) {}
};

class Vector3i : public Vector3<int>
{
public:
  Vector3i(int x = 0, int y = 0, int z = 0) : Vector3<int>(x, y, z) {}
  Vector3i(const int* i) : Vector3<int>(i) {}
};

class Vector3f : public Vector3<float>
{
public:
  Vector3f(float x = 0.0, float y = 0.0, float z = 0.0)
    : Vector3<float>(x, y, z) {}
  Vector3f(const float* i) : Vector3<float>(i) {}
};

class Vector3d : public Vector3<double>
{
public:
  Vector3d(double x = 0.0, double y = 0.0, double z = 0.0)
    : Vector3<double>(x, y, z) {}
  Vector3d(const double* i) : Vector3<double>(i) {}
};

class Recti : public Rect<int>
{
public:
  Recti(int x = 0, int y = 0, int width = 0, int height = 0)
    : Rect<int>(x, y, width, height) {}
  Recti(const int* i) : Rect<int>(i) {}
};

class Rectf : public Rect<float>
{
public:
  Rectf(float x = 0.0, float y = 0.0, float width = 0.0, float height = 0.0)
    : Rect<float>(x, y, width, height) {}
  Rectf(const float* i) : Rect<float>(i) {}
};

class Rectd : public Rect<double>
{
public:
  Rectd(double x = 0.0, double y = 0.0, double width = 0.0,
           double height = 0.0)
    : Rect<double>(x, y, width, height) {}
  Rectd(const double* i) : Rect<double>(i) {}
};

}

#endif // __vtkChartsVector_h
