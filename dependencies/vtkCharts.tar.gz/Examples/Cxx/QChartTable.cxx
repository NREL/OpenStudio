/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile$

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include <QApplication>
#include <QWidget>
#include <QMainWindow>
#include <QHBoxLayout>
#include <QTableWidget>

#include <cmath>

#include "BarChart.h"

#define NUMPOINTS (12)
static float data_2008[] = {10822, 10941, 9979, 10370, 9460, 11228, 15093, 12231, 10160, 9816, 9384, 7892};
static float data_2009[] = {9058, 9474, 9979, 9408, 8900, 11569, 14688, 12231, 10294, 9585, 8957, 8590};

//----------------------------------------------------------------------------
int main( int argc, char * argv [] )
{

  // Qt initialization
  QApplication app(argc, argv);
  QMainWindow *mainWindow = new QMainWindow;
  mainWindow->setGeometry(100, 100, 800, 600);

  std::vector<float>data_2008_vec(NUMPOINTS);
  std::vector<float>data_2009_vec(NUMPOINTS);
  for (int i = 0; i < NUMPOINTS; i++)
    {
    data_2008_vec[i] = data_2008[i];
    data_2009_vec[i] = data_2009[i];
    }

  vtkCharts::BarChart chart(data_2008_vec,std::string("2008"));
  chart.addSeries(data_2009_vec,std::string("2009"));

  QWidget *chartWidget = chart.widget(mainWindow);

  QTableWidget *tableWidget = new QTableWidget(0);
  tableWidget->setColumnCount(2);
  tableWidget->setSortingEnabled(false);
  tableWidget->setHorizontalHeaderItem(0,new QTableWidgetItem(QString("2008")));
  tableWidget->setHorizontalHeaderItem(1,new QTableWidgetItem(QString("2009")));
  tableWidget->setRowCount(NUMPOINTS);
  for (int i = 0; i < NUMPOINTS; i++) 
    {
    tableWidget->setItem(i,0,new QTableWidgetItem(QString::number(data_2008_vec[i])));
    tableWidget->setItem(i,1,new QTableWidgetItem(QString::number(data_2009_vec[i])));
    }

  QWidget *layoutWidget = new QWidget(mainWindow);
  QHBoxLayout *layout = new QHBoxLayout(layoutWidget);

  layout->addWidget(chartWidget,2);
  layout->addWidget(tableWidget);
  mainWindow->setCentralWidget(layoutWidget);

  // Now show the application and start the event loop
  mainWindow->show();

  return app.exec();
}
