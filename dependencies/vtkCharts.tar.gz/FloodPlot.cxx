/*=========================================================================

  Program:   vtkCharts
  Module:    FloodPlot.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "FloodPlot.h"
#include "BaseChartPimpl.h"
#include "Color.h"
#include "Matrix.h"

#include "vtkSmartPointer.h"
#include "vtkChartHistogram2D.h"
#include "vtkColorTransferFunction.h"
#include "vtkImageData.h"
#include "vtkPen.h"
#include "vtkBrush.h"

namespace vtkCharts {

class Histogram2DChartPimpl : public BaseChartPimpl
{
public:
  Histogram2DChartPimpl() : BaseChartPimpl(vtkChartHistogram2D::New())
    {
    this->Data = vtkSmartPointer<vtkImageData>::New();
    this->Transfer = vtkSmartPointer<vtkColorTransferFunction>::New();
    }

  ~Histogram2DChartPimpl()
    {
    }

  void SetupTransfer(double min = 0.0, double max = 1.0)
    {
    double range = max - min;
    this->Transfer->RemoveAllPoints();
    this->Transfer->AddHSVSegment(min, 0.0, 1.0, 1.0,
                                  min + 0.3333 * range, 0.3333, 1.0, 1.0);
    this->Transfer->AddHSVSegment(min + 0.3333 * range, 0.3333, 1.0, 1.0,
                                  min + 0.6666 * range, 0.6666, 1.0, 1.0);
    this->Transfer->AddHSVSegment(min + 0.6666 * range, 0.6666, 1.0, 1.0,
                                  max, 0.2, 1.0, 0.3);
    this->Transfer->Build();
    vtkChartHistogram2D *chart = vtkChartHistogram2D::SafeDownCast(this->Chart);
    chart->SetTransferFunction(this->Transfer);
    }

  void SetInput(const Matrixf& m, float xMin, float xMax,
                float yMin, float yMax,
                const std::string& name)
    {
    this->Data->SetScalarTypeToDouble();
    this->Data->SetExtent(0, m.GetCols() - 1, 0, m.GetRows() - 1, 0, 0);
    this->Data->SetNumberOfScalarComponents(1);
    this->Data->AllocateScalars();
    this->Data->SetOrigin(xMin, yMin, 0.0);
    this->Data->SetSpacing((xMax - xMin) / (m.GetCols() - 1),
                           (yMax - yMin) / (m.GetRows() - 1), 1.0);
    double *dPtr = static_cast<double *>(this->Data->GetScalarPointer(0, 0, 0));
    for (int i = 0; i < m.GetCols(); ++i)
      {
      for (int j = 0; j < m.GetRows(); ++j)
        {
        dPtr[i * m.GetRows() + j] = m(i, j);
        }
      }
    vtkChartHistogram2D *chart = vtkChartHistogram2D::SafeDownCast(this->Chart);
    chart->SetInput(this->Data);

    // Set a few default segments in the transfer function too.
    double range[2];
    this->Data->GetScalarRange(range);
    this->SetupTransfer(range[0], range[1]);
    }

  vtkSmartPointer<vtkImageData> Data;
  vtkSmartPointer<vtkColorTransferFunction> Transfer;
};

FloodPlot::FloodPlot(const Matrixf& m, float xMin, float xMax,
                                   float yMin, float yMax,
                                   const std::string& name)
{
  this->Private = new Histogram2DChartPimpl();
  static_cast<Histogram2DChartPimpl *>(this->Private)->SetInput(m, xMin, xMax,
                                                                yMin, yMax, name);
}

FloodPlot::~FloodPlot()
{
  if (this->Private)
    delete this->Private;
  this->Private = 0;
}

void FloodPlot::setInput(const Matrixf& m, float xMin, float xMax,
                                float yMin, float yMax,
                                const std::string &name)
{
  static_cast<Histogram2DChartPimpl *>(this->Private)->SetInput(m, xMin, xMax,
                                                                yMin, yMax, name);
}

} // End of vtkCharts namespace
