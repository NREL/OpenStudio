/*=========================================================================

  Program:   vtkCharts
  Module:    QChartProxy.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "QChartProxy.h"

#include "Chart.h"

#include "vtkEventQtSlotConnect.h"
#include "vtkChartXY.h"

#include <QtCore/QDebug>

namespace vtkCharts {

QChartProxy::QChartProxy(Chart *chart, QObject *parent) :
  ChartObject(chart), QObject(parent)
{
  if (this->ChartObject)
    {
    Connector->Connect(this->ChartObject->chartObject(),
                       vtkCommand::InteractionEvent,
                       this, SLOT(chartPointClicked(vtkObject*,ulong,void*,
                                                    void*, vtkCommand*))
                       );
    }
}

QChartProxy::~QChartProxy()
{
}

void QChartProxy::chartPointClicked(vtkObject *caller, unsigned long vtk_event,
                                    void *client_data, void *client_data2,
                                    vtkCommand*)
{
  vtkChartPlotData *plot = static_cast<vtkChartPlotData*>(client_data2);
//  cout << "Plot name: " << plot->SeriesName << ", index: " << plot->Position.X()
//       << ", " << plot->Position.Y() << endl;

  emit pointClicked(QString(plot->SeriesName.c_str()),
                    Vector2f(plot->Position.GetData()),
                    Vector2i(plot->ScreenPosition.GetData()));
}

} // End namespace
