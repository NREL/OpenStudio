/*=========================================================================

  Program:   vtkCharts
  Module:    Matrix.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#ifndef __vtkChartsMatrix_h
#define __vtkChartsMatrix_h

namespace vtkCharts {

/*!
 * @brief Templated base type for storage of matrices.
 *
 * This class is a templated data type for storing and manipulating variable
 * size matrices. The memory layout is a contiguous array of the specified type.
*/
template<typename T>
class Matrix
{
public:
  /*! @brief Construct a matrix. The default size is 0 rows and columns. You can
   * optionally pass in a pointer of the correct type with data to initialize
   * the matrix with.
   */
  Matrix(unsigned int rows = 0, unsigned int cols = 0, const T* init = 0)
    : Rows(rows), Cols(cols)
  {
    this->Data = new T[rows * cols];
    if (init)
      {
      for (unsigned int i = 0; i < rows; ++i)
        {
        for (unsigned int j = 0; j < cols; ++j)
          {
          this->Data[i * this->Cols + j] = init[i * this->Cols + j];
          }
        }
      }
  }

  /*! @brief Pass in a pointer of the correct type with data to copy into the
   * matrix. Defaults to copying in row-major order, specify rowMajorOrder false
   * to override.
   *
   * Expects init to be of at least length Rows * Cols.
   */
  Matrix(const T* init, bool rowMajorOrder = true)
  {
    if (init)
      {
      if (rowMajorOrder)
        {
        for (unsigned int i = 0; i < this->Rows; ++i)
          {
          for (unsigned int j = 0; j < this->Cols; ++j)
            {
            this->Data[i * this->Cols + j] = init[i * this->Cols + j];
            }
          }
        }
      else
        {
        for (unsigned int i = 0; i < this->Rows; ++i)
          {
          for (unsigned int j = 0; j < this->Cols; ++j)
            {
            this->Data[i * this->Cols + j] = init[j * this->Rows + i];
            }
          }
        }
      }
  }

  /*! @brief Resize the matrix to the specified number of rows and cols.
   */
  void Resize(unsigned int rows, unsigned int cols)
    {
    if (this->Data)
      {
      delete [] this->Data;
      }
    this->Rows = rows;
    this->Cols = cols;
    this->Data = new T[rows * cols];
    }

  /*! @brief Get the number of rows.
   */
  int GetRows() const { return this->Rows; }

  /*! @brief Get the number of columns.
   */
  int GetCols() const { return this->Cols; }

  /*! @brief Get a pointer to the underlying data of the matrix.
   */
  T* GetData() { return this->Data; }
  const T* GetData() const { return this->Data; }

  /*! @brief Get the value of the matrix at the row, column specified.
   *
   * Does bounds checking, used in much the same way as vector.at(i) is used.
   */
  T& operator()(int i, int j)
    {
    return this->Data[i * this->Cols + j];
    }
  T operator()(int i, int j) const
    {
    return this->Data[i * this->Cols + j];
    }

protected:
  unsigned int Rows;
  unsigned int Cols;
  T *Data;
};

class Matrixi : public Matrix<int>
{
public:
  Matrixi(unsigned int rows = 0, unsigned int cols = 0, const int* init = 0)
    : Matrix<int>(rows, cols, init) { }
};

class Matrixf : public Matrix<float>
{
public:
  Matrixf(unsigned int rows = 0, unsigned int cols = 0, const float* init = 0)
    : Matrix<float>(rows, cols, init) { }
};

}

#endif // __vtkChartsMatrix_h
