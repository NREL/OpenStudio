require "#{File::dirname(__FILE__)}/vtkcharts_ruby"
