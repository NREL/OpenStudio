/*=========================================================================

  Program:   vtkCharts
  Module:    Plot.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsPlot_h
#define __vtkChartsPlot_h

#include <vector>
#include <string>

class vtkPlotLine;

namespace vtkCharts {

class PlotPimpl;
class Chart;
class Color3ub;
class Color4ub;

/*! @brief Implements a basic plot.
 */
class Plot
{
public:

  /*! Pattern selection for plot lines.
   */
  enum LineStyle {
    NONE = 0,
    SOLID,
    DOTTED,
    PATTERN_1,
    PATTERN_2,
    PATTERN_3,
  };

  /*! Pattern selection for marker styles.
   */
  enum MarkerStyle {
    EMPTY,
    CROSS,
    PLUS,
    SQUARE,
    CIRCLE,
    DIAMOND
  };

  ~Plot();

  /*! @brief Set the data series to the plot.
   *
   * @param x X component of the data series to start with.  Must have the same
   * size as y.
   * @param y Y component of the data series to start with.  Must have the same
   * size as x.
   * @param seriesName The name of this series. Used for legend titles.
   */
  void setData(const std::vector<float>& x, const std::vector<float>& y,
               const std::string& seriesName);

  /*! @brief Set the Plot::LineStyle for the plot.
   *
   * @param style Choose the style of line to display.
   */
  void setLineStyle(LineStyle style);

  /*! @brief Get the Plot::LineStyle for the specified plot.
   */
  LineStyle lineStyle() const;

  /*! @brief Set the Plot::MarkerStyle for the plot.
   *
   * @param style Choose the style of the marker.
   */
  void setMarkerStyle(MarkerStyle style);

  /*! @brief Get the Plot::LineStyle for the plot.
   */
  MarkerStyle markerStyle() const;

  /*! @brief Set the size of the marker (pixels).
   *
   * @param size The size of the marker in pixels.
   */
  void setMarkerSize(float size);

  /*! @brief Get the size of the marker in pixels.
   */
  float markerSize() const;

  /*! @brief Set the color of the plot.
   *
   * @param color The color the plot should be rendered using.
   */
  void setColor(const Color3ub &color);
  void setColor(const Color4ub &color);

  /*! @brief Set the color of the plot.
   */
  Color4ub color() const;

  /*! @brief Get the underlying vtkPlotLine object.  This can be useful to
   * if low level control is required.
   */
  vtkPlotLine * plotObject();

  /*! Copy constructor. */
  Plot(const Plot &other);

  /*! Is this Plot object valid? Main reason for being invalid is having no
   * vtkPlotLine object. This is likely due to no series existing with the
   * specified name/index.
   */
  bool isValid() const;

protected:
  friend class Chart;

  /*! @brief Construct a Plot. Called by the Chart class, that this object is a
   * child of.
   */
  Plot(vtkPlotLine *plot);

  void setPlotObject(vtkPlotLine *plot);

  PlotPimpl *Private;

};

}

#endif
