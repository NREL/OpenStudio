/*=========================================================================

  Program:   vtkCharts
  Module:    Axis.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "Axis.h"

#include "vtkAxis.h"
#include "vtkDoubleArray.h"
#include "vtkStringArray.h"
#include "vtkWeakPointer.h"
#include "vtkNew.h"

namespace vtkCharts {

class AxisPimpl
{
public:
  AxisPimpl(vtkAxis *axis) : Axis(axis) {}
  vtkWeakPointer<vtkAxis> Axis;
};

Axis::Axis(vtkAxis *axis) : Private(new AxisPimpl(axis))
{
}

Axis::~Axis()
{
  delete this->Private;
}

void Axis::setTitle(const std::string &title)
{
  this->Private->Axis->SetTitle(title);
}

std::string Axis::title() const
{
  return this->Private->Axis->GetTitle();
}

void Axis::setMinimum(double value)
{
  this->Private->Axis->SetBehavior(vtkAxis::FIXED);
  this->Private->Axis->SetMinimum(value);
}

double Axis::minimum() const
{
  return this->Private->Axis->GetMinimum();
}

void Axis::setMaximum(double value)
{
  this->Private->Axis->SetBehavior(vtkAxis::FIXED);
  this->Private->Axis->SetMaximum(value);
}

double Axis::maximum() const
{
  return this->Private->Axis->GetMaximum();
}

void Axis::setRange(double minimum, double maximum)
{
  this->Private->Axis->SetBehavior(vtkAxis::FIXED);
  this->Private->Axis->SetRange(minimum, maximum);
}

void Axis::setNumberOfTicks(int ticks)
{
  this->Private->Axis->SetNumberOfTicks(ticks);
}

int Axis::numberOfTicks() const
{
  return this->Private->Axis->GetNumberOfTicks();
}

void Axis::setNotation(Notation style)
{
  this->Private->Axis->SetNotation(style);
}

Axis::Notation Axis::notation() const
{
  switch(this->Private->Axis->GetNotation())
    {
    case 0:
      return STANDARD;
    case 1:
      return SCIENTIFIC;
    case 2:
    default:
      return MIXED;
    }
}

void Axis::setPrecision(int precision)
{
  this->Private->Axis->SetPrecision(precision);
}

int Axis::precision() const
{
  return this->Private->Axis->GetPrecision();
}

void Axis::setTickLabels(const std::vector<std::string> &labels)
  {
  vtkNew<vtkStringArray> labelArray;
  vtkNew<vtkDoubleArray> positionArray;

  std::vector<std::string>::const_iterator label;
  double pos = 0;
  for (label = labels.begin(), pos = 0; label != labels.end(); ++label, ++pos)
    {
    labelArray->InsertNextValue(*label);
    positionArray->InsertNextValue(pos);
    }
  this->Private->Axis->SetTickLabels(labelArray.GetPointer());
  this->Private->Axis->SetTickPositions(positionArray.GetPointer());
  this->Private->Axis->SetMaximum(pos);

  // FIXME: Add back in the width calculation for bar charts.

  this->Private->Axis->SetMinimum(0.0);// - (this->ChartPlots.begin()->second->GetWidth()/2.0));
  }

vtkAxis * Axis::axisObject()
{
  return this->Private->Axis.GetPointer();
}

// It is all about keeping a copy of the Axis pointer.
Axis::Axis(const Axis &other) : Private(new AxisPimpl(other.Private->Axis))
{
}

void Axis::setAxisObject(vtkAxis *axis)
{
  this->Private->Axis = axis;
}

} // End of namespace
