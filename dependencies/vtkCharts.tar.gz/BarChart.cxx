/*=========================================================================

  Program:   vtkCharts
  Module:    BarChart.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "BarChart.h"
#include "Color.h"
#include "BaseChartPimpl.h"

#include <map>

#include "vtkTable.h"
#include "vtkFloatArray.h"
#include "vtkDoubleArray.h"
#include "vtkStringArray.h"

#include "vtkContextScene.h"
#include "vtkColorSeries.h"
#include "vtkPen.h"
#include "vtkBrush.h"

#include "vtkChartXY.h"
#include "vtkPlotBar.h"
#include "vtkAxis.h"
#include "vtkSmartPointer.h"

namespace vtkCharts {

class BarChartPimpl : public BaseChartPimpl
{
public:
  BarChartPimpl() : BaseChartPimpl(vtkChartXY::New())
    {
    }

  ~BarChartPimpl()
    {
    }

  void setColors(const std::vector<Color3ub>& colors)
    {
    BaseChartPimpl::setColors(colors);

    std::map<std::string, vtkSmartPointer<vtkPlotBar> >::const_iterator iter;
    int i = 0;
    for (iter = this->Plots.begin(); iter != this->Plots.end(); ++iter, ++i)
      {
      iter->second->GetBrush()->SetColor(
            this->ColorSeries->GetColorRepeating(i).GetData());
      iter->second->SetColorSeries(this->ColorSeries);
      }
    }

  void AddDataSeries(const std::string& seriesName)
    {
    // If the plot already exists, replace it
    this->RemoveDataSeries(seriesName);
    this->Plots[seriesName] =
        vtkPlotBar::SafeDownCast(this->Chart->AddPlot(vtkChartXY::BAR));
    this->Tables[seriesName] = vtkSmartPointer<vtkTable>::New();

    this->Plots[seriesName]->SetInput(this->Tables[seriesName]);
    this->Plots[seriesName]->SetUseIndexForXSeries(true);
    this->Plots[seriesName]->GetBrush()->SetColor(
          this->ColorSeries->GetColorRepeating(this->Plots.size() - 1).GetData());
    this->NumStackedFor[seriesName] = 0;
    this->Plots[seriesName]->SetGroupName(seriesName);
    }

  bool RemoveDataSeries(const std::string& seriesName)
    {
    if (this->Plots.find(seriesName) != this->Plots.end())
      {
      this->Chart->RemovePlotInstance(this->Plots[seriesName]);
      return true;
      }
    else
      {
      return false;
      }
    }

  void StackDataSeries(const std::vector<float>& series,
                       const std::string& seriesName,
                       const std::string& stackName)
    {
    if (this->Plots.find(seriesName) == this->Plots.end())
      {
      this->AddDataSeries(seriesName);
      }

    vtkSmartPointer<vtkFloatArray> floatArray =
        vtkSmartPointer<vtkFloatArray>::New();
    VectorToArray(series, floatArray);
    floatArray->SetName(stackName.c_str());
    this->Tables[seriesName]->AddColumn(floatArray);
    this->Plots[seriesName]->SetInputArray(
          1 + this->NumStackedFor[seriesName],stackName.c_str());
    this->NumStackedFor[seriesName] += 1;
    if (this->NumStackedFor[seriesName] > 1)
      {
      this->Plots[seriesName]->SetColorSeries(this->ColorSeries);
      }
    }

  void SetXTickLabels(const std::vector<std::string>& labels)
    {
    vtkSmartPointer<vtkStringArray> labelArray =
        vtkSmartPointer<vtkStringArray>::New();
    vtkSmartPointer<vtkDoubleArray> positionArray =
        vtkSmartPointer<vtkDoubleArray>::New();

    std::vector<std::string>::const_iterator label;
    double pos = 0;
    for (label = labels.begin(), pos = 0; label != labels.end(); ++label, ++pos)
      {
      labelArray->InsertNextValue(*label);
      positionArray->InsertNextValue(pos);
      }
    this->Chart->GetAxis(1)->SetTickLabels(labelArray);
    this->Chart->GetAxis(1)->SetTickPositions(positionArray);
    this->Chart->GetAxis(1)->SetMaximum(pos);

    this->Chart->GetAxis(1)->SetMinimum(
          0.0 - (this->Plots.begin()->second->GetWidth()/2.0));
    }

  std::map<std::string, vtkSmartPointer<vtkPlotBar> > Plots;
  std::map<std::string, int> NumStackedFor;
};

BarChart::BarChart(const std::vector<float>& data, const std::string& seriesName)
{
  this->Private = new BarChartPimpl();
  static_cast<BarChartPimpl *>(this->Private)->AddDataSeries(seriesName);
  static_cast<BarChartPimpl *>(this->Private)
      ->StackDataSeries(data,seriesName,seriesName);
}

BarChart::BarChart(const std::string& seriesName)
{
  this->Private = new BarChartPimpl();
  static_cast<BarChartPimpl *>(this->Private)->AddDataSeries(seriesName);
}

BarChart::~BarChart()
{
  if (this->Private)
    delete this->Private;
  this->Private = 0;
}

void BarChart::addSeries(const std::vector<float>& series,
                         const std::string& seriesName)
{
  static_cast<BarChartPimpl *>(this->Private)->AddDataSeries(seriesName);
  static_cast<BarChartPimpl *>(this->Private)
      ->StackDataSeries(series,seriesName,seriesName);
}

bool BarChart::removeSeries(const std::string &seriesName)
{
  return static_cast<BarChartPimpl *>(this->Private)
      ->RemoveDataSeries(seriesName);
}

void BarChart::stackSeries(const std::vector<float>& series,
                           const std::string& seriesName,
                           const std::string& stackName)
{
  static_cast<BarChartPimpl *>(this->Private)
      ->StackDataSeries(series,seriesName,stackName);
}

void BarChart::setXTickLabels(const std::vector<std::string>& labels)
{
  static_cast<BarChartPimpl *>(this->Private)->SetXTickLabels(labels);
}

} // End of vtkCharts namespace
