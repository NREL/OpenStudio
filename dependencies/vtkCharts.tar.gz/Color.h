/*=========================================================================

  Program:   Visualization Toolkit
  Module:    Color.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

// .NAME vtkCharts::Color - templated type for storage of colors.
//
// .SECTION Description
// This class is a templated data type for storing and manipulating fixed size
// colors. It derives from the vtkCharts::Vector templated data structure.

#ifndef __vtkChartsColor_h
#define __vtkChartsColor_h

#include "ColorBase.h"

namespace vtkCharts {

// Description:
// Some derived classes for the different vectors and colors commonly used.
class Color3ub : public Color3<unsigned char>
{
public:
  Color3ub(unsigned char r = 0, unsigned char g = 0,
              unsigned char b = 0) : Color3<unsigned char>(r, g, b) {}
};

class Color3f : public Color3<float>
{
public:
  Color3f(float r = 0.0, float g = 0.0, float b = 0.0)
    : Color3<float>(r, g, b) {}
};

class Color3d : public Color3<double>
{
public:
  Color3d(double r = 0.0, double g = 0.0, double b = 0.0)
    : Color3<double>(r, g, b) {}
};

class Color4ub : public Color4<unsigned char>
{
public:
  Color4ub(unsigned char r = 0, unsigned char g = 0,
              unsigned char b = 0, unsigned char a = 255)
                : Color4<unsigned char>(r, g, b, a) {}
};

class Color4f : public Color4<float>
{
public:
  Color4f(float r = 0.0, float g = 0.0, float b = 0.0, float a = 1.0)
    : Color4<float>(r, g, b, a) {}
};

class Color4d : public Color4<double>
{
public:
  Color4d(double r = 0.0, double g = 0.0, double b = 0.0, float a = 1.0)
    : Color4<double>(r, g, b, a) {}
};
}

#endif // __vtkCharts::Color_h
