/*=========================================================================

  Program:   vtkCharts
  Module:    BaseChartsPimpl.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "BaseChartPimpl.h"

#include "Color.h"

#ifdef vtkCharts_USE_QT
# include "QVTKWidget.h"
#endif

#include "vtkContextView.h"
#include "vtkContextScene.h"
#include "vtkChartXY.h"
#include "vtkContext2D.h"
#include "vtkColorSeries.h"
#include "vtkWindowToImageFilter.h"
#include "vtkRenderWindow.h"
#include "vtkWindow.h"
#include "vtkPNGWriter.h"
#include "vtkJPEGWriter.h"
#include "vtkTesting.h"
#include "vtkFloatArray.h"

namespace vtkCharts {

BaseChartPimpl::BaseChartPimpl(vtkChart *chart)
{
  this->Chart.TakeReference(chart);
  this->Context = vtkSmartPointer<vtkContextView>::New();
  this->ColorSeries = vtkSmartPointer<vtkColorSeries>::New();

#ifdef vtkCharts_USE_QT
  this->VTKWidget = new QVTKWidget;
  this->Context->SetInteractor(this->VTKWidget->GetInteractor());
  this->VTKWidget->SetRenderWindow(this->Context->GetRenderWindow());

  this->VTKWidget->setGeometry(0, 0, 640, 480);
#else
  this->Context->GetRenderWindow()->SetSize(640, 480);
#endif
  this->Context->GetScene()->AddItem(this->Chart);
  this->FileType = BaseChart::PNG;
}

BaseChartPimpl::~BaseChartPimpl()
{
#ifdef vtkCharts_USE_QT
  if (this->VTKWidget)
    delete this->VTKWidget;
#endif
}

void BaseChartPimpl::save(const std::string& fileName)
{
#ifdef vtkCharts_USE_QT
  this->VTKWidget->show();
#endif
  vtkSmartPointer<vtkWindowToImageFilter> imageFilter =
      vtkSmartPointer<vtkWindowToImageFilter>::New();
  imageFilter->SetInput(this->Context->GetRenderWindow());
  this->Context->Render();

  switch (this->FileType)
    {
    case BaseChart::PNG:
      {
        vtkSmartPointer<vtkPNGWriter> pngWriter =
            vtkSmartPointer<vtkPNGWriter>::New();
        pngWriter->SetFileName(fileName.c_str());
        pngWriter->SetInput(imageFilter->GetOutput());
        pngWriter->Write();
      }
      break;
    case BaseChart::JPEG:
      {
        vtkSmartPointer<vtkJPEGWriter> jpegWriter =
            vtkSmartPointer<vtkJPEGWriter>::New();
        jpegWriter->SetFileName(fileName.c_str());
        jpegWriter->SetInput(imageFilter->GetOutput());
        jpegWriter->Write();
      }
    }
}

void BaseChartPimpl::setColors(const std::vector<Color3ub>& colors)
  {
  this->ColorSeries->ClearColors();
  std::vector<Color3ub>::const_iterator color;
  for (color = colors.begin(); color != colors.end(); color++)
    {
    Color3ub color3 = *color;
    this->ColorSeries->AddColor(vtkColor3ub(color3.Red(), color3.Green(),
                                            color3.Blue()));
    }
  }

BaseChart::TestReturn BaseChartPimpl::test(int argc,char *argv[],
                                           double threshold)
{
#ifdef vtkCharts_USE_QT
  this->VTKWidget->show();
#endif
  int multiSamples = this->Context->GetRenderWindow()->GetMultiSamples();
  this->Context->GetRenderWindow()->SetMultiSamples(0);
  BaseChart::TestReturn retVal = static_cast<BaseChart::TestReturn>(
    vtkTesting::Test(argc, argv, this->Context->GetRenderWindow(), threshold));
  this->Context->GetRenderWindow()->SetMultiSamples(multiSamples);
  return retVal;
}

} //End of vtkCharts namespace
