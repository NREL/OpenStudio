/*=========================================================================

  Program:   vtkCharts
  Module:    BaseChartsPimpl.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef __vtkChartsBaseChartPimpl_h
#define __vtkChartsBaseChartPimpl_h

#include <map>
#include <vector>

#ifdef vtkCharts_USE_QT
# include <QPointer>
#endif

#include "vtkSmartPointer.h"    // For ivars
#include "BaseChart.h" // For public enums
#include "vtkFloatArray.h"

class QVTKWidget;
class vtkContextView;
class vtkChart;
class vtkColorSeries;
class vtkTable;
class vtkPlot;

namespace vtkCharts {
  
class BaseChartPimpl
{
public:
  BaseChartPimpl(vtkChart *chart);
  virtual ~BaseChartPimpl();

  void save(const std::string& fileName);
  virtual void setColors(const std::vector<Color3ub>& colors);
  BaseChart::TestReturn test(int argc, char *argv[], double threshold);

  void VectorToArray(const std::vector<float>& vec, vtkFloatArray *array);

  vtkSmartPointer<vtkContextView> Context;
  vtkSmartPointer<vtkColorSeries> ColorSeries;
  BaseChart::FileType FileType;
  std::map<std::string, vtkSmartPointer<vtkTable> > Tables;
#ifdef vtkCharts_USE_QT
  QPointer<QVTKWidget> VTKWidget;
#endif
  vtkSmartPointer<vtkChart> Chart;
};

inline void BaseChartPimpl::VectorToArray(const std::vector<float>& vec,
                                          vtkFloatArray *array)
{
  std::vector<float>::const_iterator i;
  for (i = vec.begin(); i != vec.end(); ++i)
    {
    array->InsertNextValue(*i);
    }
}

}

#endif
